# Brilliant-Max Chess v1.3.1

## Why this patch exists

The v1.3 build failed before compilation because the Gradle Kotlin DSL referenced `java.security` and the lambda type could not be inferred. More importantly, the Android runtime later exposed a real model-format issue: the previous file had a `.ptl` extension but did not contain the Lite Interpreter `bytecode.pkl` archive.

## Fixed

- Fixed Gradle `MessageDigest` imports and byte-lambda typing.
- Added a build-time check that the Prior asset contains `bytecode.pkl`.
- Re-exported the frozen v1.52 Prior with `_save_for_lite_interpreter()`.
- Preserved exact numerical parity with the previous model artifact: max absolute error `0.0` on the 20-move start-position smoke test.
- Stockfish CI preparation now explicitly runs `make net` before the Android build.
- Added Android instrumentation tests for:
  - Lite Prior load + ranking
  - Stockfish startup + measured nodes
  - combined Prior → Stockfish BMC search
- Version bumped to 1.3.1 / versionCode 131.

## Status

This is still a compatibility bridge using the legacy PyTorch Lite runtime. The production runtime target remains ExecuTorch `.pte`.
