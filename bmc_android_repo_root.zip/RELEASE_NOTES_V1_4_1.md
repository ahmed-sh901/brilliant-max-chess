# BMC Android v1.4.1 — CI build fix + verifier hardening

## Build fix
- Fixes the Gradle Kotlin DSL failure caused by fully-qualified `java.security.MessageDigest` references.
- Uses the explicit `MessageDigest` import consistently.
- Makes digest lambda byte types explicit so Kotlin DSL script compilation is deterministic.
- Bumps app version to 1.4.1 / versionCode 141.

## Runtime scope
- Keeps the v1.52 seven-head Prior Lite model unchanged.
- Keeps the pinned Stockfish 19 verifier build for arm64-v8a and x86_64.
- Keeps the legal orthodox chess layer and perft coverage.
- Keeps the instrumentation tests for Prior, Stockfish and the combined BMC search.

## Truth contract
This release is an implementation/CI milestone. It makes no claim about playing strength, Elo, or superiority. The Prior proposes candidates; Stockfish provides the soundness gate.
