import com.brilliantmax.chess.*
fun perft(p:ChessPosition,d:Int):Long=if(d==0)1 else p.legalMoves().sumOf{perft(p.apply(it),d-1)}
fun main(){println(perft(ChessPosition.start(),1));println(perft(ChessPosition.start(),2));println(perft(ChessPosition.start(),3));val p=ChessPosition.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1");println(p.legalMoves().map{it.uci()}.filter{it.startsWith("e1")} )}
