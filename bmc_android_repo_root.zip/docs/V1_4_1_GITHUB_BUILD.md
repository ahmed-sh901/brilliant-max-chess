# BMC Android v1.4.1 — GitHub build fix

This packaging fixes the Gradle JVM target mismatch found on the first GitHub Actions build.

Java compile source/target and Kotlin JVM target are aligned to Java 17. The bundled v1.52 TorchScript model and checksum metadata are included.

This is still a build/handoff milestone; native TorchScript inference/search integration is not complete.
