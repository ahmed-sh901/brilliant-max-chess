# v1.3.1 model-runtime fix

The previous Android artifact was named `.ptl` but was saved with ordinary TorchScript `save()`. `LiteModuleLoader.load()` requires a model produced by `_save_for_lite_interpreter()` and therefore failed with `PytorchStreamReader failed locating file bytecode.pkl`.

v1.3.1 re-exports the frozen v1.52 Move-Aware 7-head model with `_save_for_lite_interpreter()` and verifies that `bytecode.pkl` is present.

Validation performed before packaging:
- TorchScript Lite desktop loader accepted the new artifact.
- Starting-position 20-move output parity against the previous artifact: max absolute error `0.0`.
- Model SHA-256: `5c19aa3899a112fd9af7b9fe034e1320137bddebd32c4545e74f0e645081f7ca`.

The Android project also contains instrumentation tests for Prior loading, Stockfish node measurement, and the combined BMC search path. CI should run those tests on an API-35 x86_64 emulator with ARM64 translation before an APK is handed to the user.
