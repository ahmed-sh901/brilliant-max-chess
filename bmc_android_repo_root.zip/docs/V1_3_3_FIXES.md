# v1.3.3 fixes

## Build failure fixed
The previous CI failure was not an Android SDK/NDK failure. Gradle Kotlin DSL was compiling `java.security.MessageDigest.getInstance(...)` as an unresolved `java.security` reference in this script context. v1.3.3 imports `java.security.MessageDigest` and calls `MessageDigest.getInstance(...)` directly.

## Model move contract
`ChessMove` uses Q/R/B/N promotion values 5/4/3/2 for its UI/rules layer. The frozen v1.52 model expects 1/2/3/4 for Q/R/B/N. The bridge now performs that conversion before inference.
