# Build

Open this folder in Android Studio and build the `app` module.

Target:
- compileSdk 36
- targetSdk 36
- minSdk 26
- arm64-v8a

The app is intentionally not claiming to be the finished engine yet.
Before release, add:
1. trained exported Brilliant-Max model;
2. production native verifier;
3. model runtime dependency;
4. legal-move/FEN/PGN implementation;
5. profiling on the Xiaomi 13;
6. signed release build.

The APK should be tested on the actual target phone before choosing CPU vs GPU
inference as the default.
