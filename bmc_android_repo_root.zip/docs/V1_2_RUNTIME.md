# BMC Android v1.2 — Prior Runtime Milestone

This milestone bundles the frozen v1.52 seven-head TorchScript Lite model and runs it on-device using the legacy PyTorch Lite Android runtime.

It is an intentional bridge milestone because the model already exists as `.ptl`. PyTorch Mobile is no longer actively supported; the production migration target is ExecuTorch `.pte` + XNNPACK/Vulkan. See the release notes for the distinction.

Current scope:
- model bundled in `app/src/main/assets/`
- model load is verified at app startup
- real model inference is executed for the 20 legal moves of the standard starting position
- UI displays top-5 Prior candidates
- no Stockfish verifier
- no full legal move generator
- no claim of chess playing strength
