# v1.3 engine path

`BmcSearch` now performs the intended first mobile integration loop:

1. Parse FEN into the local orthodox chess position.
2. Generate legal root moves.
3. Rank all legal root moves with the v1.52 seven-head Prior.
4. Keep the top creative candidates.
5. Verify each selected move with Stockfish 19 under an explicit node budget.
6. Compute immediate sacrifice offer, accepted-capture hook, and response-space reduction.
7. Return only candidates with measured verifier output; soundness is determined from the verifier score/mate result, not from the Prior.

The current mobile budget is deliberately modest (`2,000,000` nodes default, 8 candidates) for a functional integration milestone. It is not a claim about final mobile strength or throughput.

Stockfish 19 is built in CI from the official `sf_19` tag (`edb0d9d`) for Android arm64-v8a. Its NNUE is shipped as a separate asset and loaded through UCI `EvalFile`.
