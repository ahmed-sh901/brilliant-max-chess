# BMC Android v1.3 — engine layer

This milestone replaces the fixed opening-position smoke test with an actual orthodox chess state layer and a Prior→Stockfish verification pipeline.

## Runtime path

`FEN → legal move generation → v1.52 Prior ranking → creative candidate selection → Stockfish 19 per-candidate node-limited verification → soundness / sacrifice offer / response-space reduction → ranked discoveries`

The Prior remains a proposal policy. It is never treated as the soundness authority.

## Stockfish

The Android arm64 verifier is built during CI from official Stockfish `sf_19` (commit `edb0d9d` at the release) using the Android NDK. The compatible default network is `nn-1a298aa575a0.nnue` from the official Stockfish networks repository. The app does not claim that Stockfish and BMC have equal budgets unless the node ledger explicitly says so.

Stockfish is GPL-3.0. Source: https://github.com/official-stockfish/Stockfish
Network repository: https://github.com/official-stockfish/networks

## Current search policy

- Candidate cap: 8
- Default verifier budget: 2,000,000 measured Stockfish nodes per position, divided evenly across selected candidates.
- A move is marked `sound` only when the verifier returns a finite score >= -80 cp, or a positive mate result.
- Immediate sacrifice is only an `offer` heuristic: after the move, an opponent legal capture exists against the moved piece.
- `acceptedCapture` is a conservative PV hook and is not sufficient by itself for brilliance.
- Legal response reduction is reported as a structural signal, not the full engine viable-response metric yet.

The next research layer will replace the structural response count with engine viability thresholds and add deeper sacrifice-chain confirmation.
