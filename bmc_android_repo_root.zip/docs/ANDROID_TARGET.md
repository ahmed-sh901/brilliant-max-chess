# Xiaomi 13 target

The target is Xiaomi 13 8 GB.

Official Xiaomi specifications list Snapdragon 8 Gen 2, Adreno GPU and LPDDR5X
memory. The application therefore uses arm64-v8a only.

## Runtime design

### CPU
The search verifier is native C++ and is designed to use the 8-core CPU with
an adaptive thread count. Maximum mode may use all available logical CPU cores;
the UI remains on Android's main thread.

### Neural prior
The trained prior should be exported to an INT8-friendly runtime. The app
keeps the runtime boundary isolated so the final model backend can be selected
after profiling.

### GPU
GPU is not forced for every inference. Android's current documentation says
NNAPI is deprecated and recommends alternatives such as a TensorFlow Lite GPU
runtime for performance-critical ML. The final build should benchmark CPU
INT8 versus the chosen GPU backend on the actual Xiaomi 13 rather than assume
the GPU is faster for a small transformer.

### Thermal
Long analysis must expose:
- node budget
- elapsed time
- depth
- nodes
- CPU thread count
- inference backend
- thermal/temperature state when available.

The goal is maximum sustained performance, not a short benchmark burst that
throttles after several minutes.
