# BMC Android v1.3 — Prior + Native Stockfish Integration

## Status

Implementation milestone: **v1.3 source-complete for the first real Android search path**.

This release is not claimed as an APK build until GitHub Actions compiles the Android NDK target.

## Runtime path

`FEN -> LegalMoveGenerator -> v1.52 Prior -> top creative candidates -> native Stockfish 19 verifier -> soundness/response-space/sacrifice audit -> ranked lines`

## Prior

The frozen v1.52 Move-Aware 7-head TorchScript Lite model remains the policy model. The Android runtime evaluates the full legal move list for the current position (up to the engine's legal-move maximum) and then sends the highest-policy candidates to verification.

The Prior is a search guide only. It does not establish chess soundness.

## Legal move generator

Kotlin implementation includes:
- pawn moves and double pushes
- captures
- promotions
- en-passant
- castling
- king-safety filtering
- FEN parse/serialize
- immutable apply-move state transitions

Validation includes canonical perft checks:
- start: 20 / 400 / 8902
- Kiwipete: 48 / 2039 / 97862
- discovered-check position: 14 / 191 / 2812

These are correctness tests for move generation, not playing-strength benchmarks.

## Native Stockfish

Stockfish source is bundled under `app/src/main/cpp/stockfish` from the supplied Stockfish source package. The Android build targets arm64-v8a and uses the Stockfish Engine API directly from JNI rather than spawning a UCI subprocess.

The NNUE network is downloaded by the Gradle preparation task and validated using the hash encoded in its official filename before being packaged into the app assets.

Verifier behavior:
1. run a baseline Stockfish search on the FEN;
2. divide the requested node budget across the baseline and Prior candidates;
3. re-search each candidate with `searchmoves` restricted to that candidate;
4. record score, depth, nodes, bestmove and PV;
5. expose the evaluation loss relative to the baseline.

The current Android verifier is deliberately single-threaded for reproducible node accounting.

## Creative audit

The first integrated audit reports:
- soundness (`loss <= 80cp` or mate-equivalent score handling)
- sacrifice offer (non-pawn moved piece is attacked after the move)
- accepted sacrifice (PV captures the moved piece within the next four plies)
- response-space reduction
- a conservative `creative` flag requiring soundness plus at least one creative structural signal

This is an internal research classifier, not a claim of reproducing Chess.com's private Brilliant classifier.

## Not yet claimed

- no Elo claim
- no claim of beating Stockfish
- no equal-node benchmark result from Android
- no performance claim for the Xiaomi 13 until measured on-device
- no claim that the current creative rule is the final BMC brilliant score

## Next research layer after Android validation

Once the complete path builds and passes runtime smoke tests, the next engineering phase is to replace the conservative first-pass verifier allocation with the full BMC search policy: forcing expansion, candidate diversity, exact node-ledger accounting, chain detection, Pareto ranking, and then an Android benchmark harness against the established desktop verifier.
