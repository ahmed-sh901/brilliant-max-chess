# Stockfish license / source notice

BMC Android uses Stockfish 19 as a verifier. Stockfish is free software distributed under GPL-3.0.

Exact source used by CI:
- Repository: https://github.com/official-stockfish/Stockfish
- Tag: `sf_19`
- Release commit: `edb0d9d`
- Build target: Android arm64-v8a, `COMP=ndk`, `ARCH=armv8`

The compatible Stockfish 19 default NNUE network is:
- `nn-1a298aa575a0.nnue`
- Network repository: https://github.com/official-stockfish/networks
- Network license: CC0-1.0 as documented by the network repository.

The build downloads the source and network during CI rather than storing the large third-party binary/source tree in the BMC project archive.
