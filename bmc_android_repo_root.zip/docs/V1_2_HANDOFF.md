# Android v1.2 model handoff

The Android project now contains a verified copy of the supported v1.52 Move-Aware 7-head model export in `MODEL_DROPZONE/`.

This does **not** mean the model is executable on Android. The export is a PyTorch state-dict package. A mobile inference runtime still needs to be selected and integrated.

The project intentionally remains uncompiled because no Android SDK/Gradle toolchain is available in the current environment.
