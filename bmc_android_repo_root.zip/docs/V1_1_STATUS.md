# v1.1 status

This is an APK-ready Android project skeleton, not a falsely claimed compiled
APK.

Completed:
- Android application shell
- portrait analysis-board UI
- native arm64-v8a boundary
- background analysis worker
- 50M-node default max-mode budget
- native C++ optimization flags
- model/search separation
- Xiaomi 13 target profile
- documentation for CPU/GPU/thermal strategy

Not yet embedded:
- trained Brilliant-Max weights
- production chess move generator
- native Stockfish verifier binary
- final INT8 inference runtime
- full board-state/PGN implementation
- compiled signed APK

Reason: the trained model and production verifier do not exist yet, and this
environment has no Android SDK/Gradle toolchain available for a trustworthy
APK compilation. The project is structured so those pieces can be inserted
without changing the analysis-board UI.
