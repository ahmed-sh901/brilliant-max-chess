# App architecture

```text
                 Android UI
                    │
              AnalysisController
                    │
               JNI boundary
                    │
        ┌───────────┴───────────┐
        │                       │
 Brilliant Prior            Native Search
 INT8 / batched             multi-threaded
 candidate scoring          verification
        │                       │
        └───────────┬───────────┘
                    ↓
             creative ranking
                    ↓
        Analysis lines / PV / motifs
```

The UI is intentionally thin. Search must never run on the Android main thread.

The final app should provide:
- board editing
- FEN/PGN import/export
- move list
- MultiPV
- depth/nodes/NPS
- evaluation graph
- brilliant-candidate markers
- sacrifice-chain visualization
- response-space indicator
- engine/prior settings
- analysis budget slider
- continuous analysis
- stop/resume
- orientation/board themes
- local model management

The search engine and model remain replaceable modules so training changes do
not require rewriting the UI.
