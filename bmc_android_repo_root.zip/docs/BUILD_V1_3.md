# v1.3 build

GitHub Actions remains the canonical Android build environment.

The Gradle build now:
1. verifies the frozen Prior archive through the existing CI step;
2. validates/downloads the Stockfish NNUE network using its filename hash;
3. compiles bundled Stockfish C++ through Android NDK/CMake;
4. compiles the Kotlin board/Prior/verifier layer;
5. runs unit tests including legal-move perft checks;
6. packages the debug APK.

No local Android SDK/NDK is assumed.
