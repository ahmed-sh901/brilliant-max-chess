# BMC Android v1.4 — GitHub build handoff

## Purpose

v1.4 moves Android compilation to GitHub Actions so development can continue without a local PC or Android toolchain.

## CI environment

- Ubuntu GitHub-hosted runner
- JDK 17
- Android SDK API 36
- Build Tools 36.0.0
- NDK 27.2.12479018
- CMake 3.22.1
- Gradle 8.13

The workflow uses `android-actions/setup-android` and `gradle/actions/setup-gradle`.

## Validation

Before the Gradle build, CI verifies the TorchScript model's SHA-256 when the export metadata contains one. The APK is then produced with `assembleDebug`, and the debug APK is uploaded as a workflow artifact.

## What is deliberately not claimed

The native bridge in this handoff is still a skeleton. Building the APK does not mean the model is loaded or that chess analysis is operational. The next engineering phase is to implement and test the native inference path and then connect it to the existing analysis controller.
