# Android v1.3 handoff

The supported v1.52 Move-Aware 7-head model now has a TorchScript mobile artifact in `MODEL_DROPZONE/mobile_prior_v52_7head_mix2250.ptl`.

Next native integration tasks:
1. Parse FEN into the exact tensor contract.
2. Enumerate legal moves with the Android chess rules layer.
3. Encode candidates as `[from,to,promotion]` int64.
4. Load the PTL model and run candidate batches.
5. Convert seven logits into the existing policy score.
6. Pass the top candidate set into the native verifier.
7. Surface verifier results, nodes, and creative/sacrifice metadata.

The project is not yet a compiled APK.
