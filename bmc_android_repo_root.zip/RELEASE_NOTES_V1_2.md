# v1.2 — Model Runtime Bundled

## What changed
- Bundled `mobile_prior_v52_7head_mix2250.ptl` in Android assets.
- Added `org.pytorch:pytorch_android_lite:1.13.1` runtime dependency.
- Added Java 17 compile/Kotlin target alignment.
- Added real TorchScript Lite model loading and inference.
- Added exact v1.52 tensor contract in Kotlin.
- Added start-position candidate encoding for all 20 legal moves.
- Added visible top-5 Prior output.
- Added a starting chess position to the board UI.

## What this does NOT mean
- This is not yet the full BMC engine.
- The Prior is a ranking model, not the soundness verifier.
- Stockfish/deep verification is not yet connected to Android.
- The full legal move generator and game-state/PGN layer are still pending.
- No Elo/playing-strength claim is made.

## Runtime strategy
The `.ptl` bridge is deliberately temporary. Current PyTorch documentation says PyTorch Mobile is no longer actively supported and recommends ExecuTorch. The next production runtime migration is `.pte` + ExecuTorch, after we establish the on-device smoke test with the already-frozen model.
