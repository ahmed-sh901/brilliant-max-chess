# BMC Android v1.4.0

## Engine-build hardening

- Builds pinned Stockfish 19 (`sf_19`, revision `edb0d9d`) for both `arm64-v8a` and `x86_64`.
- Uses separate source trees per ABI so Make does not reuse objects built for another architecture.
- Validates the NDK compilers before building.
- Keeps the Stockfish 19 NNUE network checksum in the APK assets.
- The Android emulator can now exercise the same Stockfish process bridge used by arm64 devices.
- Keeps the frozen v1.52 Prior Lite model and checksum verification.

## Search layer

- Real FEN parsing and legal move generation are covered by orthodox perft tests.
- Prior ranks the complete legal root move list, not a fixed opening list.
- Stockfish verifies each selected candidate with an explicit node budget.
- Search output reports measured nodes, depth, PV, sacrifice offer, accepted capture, and response-count reduction.

This release is an implementation milestone, not a claim about playing strength.
