import torch, json, hashlib
from pathlib import Path
import sys
sys.path.insert(0,'/mnt/data/bmc_source_tmp')
from src.model.prior_v52 import BrilliantPriorV52

ckpt=Path('/mnt/data/_bmc_v13/MODEL_DROPZONE/mobile_prior_v52_7head_mix2250.pt')
out=Path('/mnt/data/_bmc_v13/MODEL_DROPZONE/mobile_prior_v52_7head_mix2250.ptl')
ck=torch.load(ckpt,map_location='cpu',weights_only=True)
cfg=ck['manifest']['config']
m=BrilliantPriorV52(d_model=cfg['d_model'],layers=cfg['layers'],heads=cfg['heads'],output_heads=cfg['output_heads'])
m.load_state_dict(ck['state_dict']); m.eval()
class MobilePrior(torch.nn.Module):
    def __init__(self,m): super().__init__(); self.m=m
    def forward(self,pieces,side,castling,ep,candidates):
        return self.m({'pieces':pieces,'side':side,'castling':castling,'ep':ep},candidates)
w=MobilePrior(m).eval()
pieces=torch.zeros(1,64,dtype=torch.long); side=torch.zeros(1,1,dtype=torch.long); cast=torch.zeros(1,1,dtype=torch.long); ep=torch.full((1,1),-1,dtype=torch.long); cand=torch.tensor([[[0,1,0],[1,18,0],[6,21,0],[12,28,0]]],dtype=torch.long)
tr=torch.jit.trace(w,(pieces,side,cast,ep,cand),strict=False,check_trace=False)
tr._save_for_lite_interpreter(str(out))
print('saved',out, out.stat().st_size)
# desktop lite smoke test
lite=torch._C._load_for_lite_interpreter(str(out),None)
# parity on smoke inputs
a=tr(pieces,side,cast,ep,cand); b=lite.run_method('forward',(pieces,side,cast,ep,cand))
print('parity',float((a-b).abs().max()))
# compare against previous model with the full start position candidate set
old=torch.jit.load('/mnt/data/_bmc_v13/MODEL_DROPZONE/mobile_prior_v52_7head_mix2250.ptl',map_location='cpu')
pieces=torch.tensor([[10,8,9,11,12,9,8,10,7,7,7,7,7,7,7,7]+[0]*32+[1,1,1,1,1,1,1,1,4,2,3,5,6,3,2,4]],dtype=torch.long)
side=torch.tensor([0],dtype=torch.long); cast=torch.tensor([15],dtype=torch.long); ep=torch.tensor([-1],dtype=torch.long)
ms=['a2a3','a2a4','b2b3','b2b4','c2c3','c2c4','d2d3','d2d4','e2e3','e2e4','f2f3','f2f4','g2g3','g2g4','h2h3','h2h4','b1a3','b1c3','g1f3','g1h3']
def sq(s): return (8-int(s[1]))*8+ord(s[0])-97
candidates=torch.tensor([[[sq(x[:2]),sq(x[2:4]),0] for x in ms]],dtype=torch.long)
oldout=old.forward(pieces,side,cast,ep,candidates)
newout=lite.run_method('forward',(pieces,side,cast,ep,candidates))
print('full parity vs old',float((oldout-newout).abs().max()),float((oldout-newout).abs().mean()))
with __import__('zipfile').ZipFile(out) as z: print('bytecode',any(x.endswith('bytecode.pkl') for x in z.namelist()))
print('sha',hashlib.sha256(out.read_bytes()).hexdigest())
