package com.brilliantmax.chess

import org.junit.Assert.assertEquals
import org.junit.Test

class FenBoardTest {
    @Test fun startFenRoundTrips() { assertEquals("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", FenBoard.start().fen()) }
    @Test fun e4UpdatesEpAndSide() { assertEquals("rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1", FenBoard.start().apply("e2e4").fen()) }
    @Test fun castlingMovesRook() { assertEquals('R', FenBoard.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1").apply("e1g1").squares[FenBoard.square("f1")]) }
}
