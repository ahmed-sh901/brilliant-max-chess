package com.brilliantmax.chess

import org.junit.Assert.assertEquals
import org.junit.Test

class ChessPositionTest {
    private fun perft(p:ChessPosition,d:Int):Long{if(d==0)return 1;var n=0L;for(m in p.legalMoves()){val q=p.copy();q.make(m);n+=perft(q,d-1)};return n}
    @Test fun startPerft(){val p=ChessPosition.start();assertEquals(20,perft(p,1));assertEquals(400,perft(p,2));assertEquals(8902,perft(p,3))}
    @Test fun fenRoundTrip(){val f="r3k2r/ppp2ppp/2n5/8/2B1P3/2N5/PPP2PPP/R3K2R w KQkq - 0 1";assertEquals(f,ChessPosition.fromFen(f).fen())}
    @Test fun castling(){val p=ChessPosition.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1");assertEquals(setOf("e1g1","e1c1"),p.legalMoves().map{it.uci()}.filter{it=="e1g1"||it=="e1c1"}.toSet())}
    @Test fun enPassant(){val p=ChessPosition.fromFen("8/8/8/3pP3/8/8/8/4K2k w - d6 0 1");assert(p.legalMoves().any{it.uci()=="e5d6"})}
}
