package com.brilliantmax.chess

import org.junit.Assert.assertEquals
import org.junit.Test

class ChessPositionTest {
    private fun perft(p: ChessPosition, depth: Int): Long {
        if (depth == 0) return 1
        var n = 0L
        for (m in p.legalMoves()) n += perft(p.apply(m), depth - 1)
        return n
    }

    @Test fun startPerft() {
        assertEquals(20, perft(ChessPosition.start(), 1))
        assertEquals(400, perft(ChessPosition.start(), 2))
        assertEquals(8902, perft(ChessPosition.start(), 3))
    }

    @Test fun kiwipetePerft() {
        val p = ChessPosition.fromFen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1")
        assertEquals(48, perft(p, 1))
        assertEquals(2039, perft(p, 2))
        assertEquals(97862, perft(p, 3))
    }

    @Test fun discoveredCheckPositionPerft() {
        val p = ChessPosition.fromFen("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1")
        assertEquals(14, perft(p, 1))
        assertEquals(191, perft(p, 2))
    }

    @Test fun startFenRoundTrip() = assertEquals(ChessPosition.START_FEN, ChessPosition.fromFen(ChessPosition.START_FEN).fen())
}
