package com.brilliantmax.chess

import org.junit.Assert.assertEquals
import org.junit.Test

class ChessPositionTest {
    private fun perft(p: ChessPosition, d: Int): Long {
        if (d == 0) return 1
        var n = 0L
        for (m in p.legalMoves()) {
            val q = p.copy()
            q.make(m)
            n += perft(q, d - 1)
        }
        return n
    }

    @Test fun startPerft() {
        val p = ChessPosition.start()
        assertEquals(20, perft(p, 1))
        assertEquals(400, perft(p, 2))
        assertEquals(8902, perft(p, 3))
        assertEquals(197281, perft(p, 4))
    }

    @Test fun kiwipetePerft() {
        val p = ChessPosition.fromFen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1")
        assertEquals(48, perft(p, 1))
        assertEquals(2039, perft(p, 2))
        assertEquals(97862, perft(p, 3))
    }

    @Test fun tacticalPerftPositions() {
        val p3 = ChessPosition.fromFen("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1")
        assertEquals(14, perft(p3, 1))
        assertEquals(191, perft(p3, 2))
        assertEquals(2812, perft(p3, 3))

        val p4 = ChessPosition.fromFen("r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1")
        assertEquals(6, perft(p4, 1))
        assertEquals(264, perft(p4, 2))
        assertEquals(9467, perft(p4, 3))
    }

    @Test fun fenRoundTrip() {
        val f = "r3k2r/ppp2ppp/2n5/8/2B1P3/2N5/PPP2PPP/R3K2R w KQkq - 0 1"
        assertEquals(f, ChessPosition.fromFen(f).fen())
    }

    @Test fun castling() {
        val p = ChessPosition.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")
        assertEquals(setOf("e1g1", "e1c1"), p.legalMoves().map { it.uci() }.filter { it == "e1g1" || it == "e1c1" }.toSet())
    }

    @Test fun enPassant() {
        val p = ChessPosition.fromFen("8/8/8/3pP3/8/8/8/4K2k w - d6 0 1")
        assert(p.legalMoves().any { it.uci() == "e5d6" })
    }
}
