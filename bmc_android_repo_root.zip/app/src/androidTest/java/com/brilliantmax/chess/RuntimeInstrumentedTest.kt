package com.brilliantmax.chess

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RuntimeInstrumentedTest {
    private val context = InstrumentationRegistry.getInstrumentation().targetContext

    @Test
    fun priorLiteModelLoadsAndRanksStartPosition() {
        val prior = PriorEngine(context)
        prior.load().getOrThrow()
        val position = ChessPosition.start()
        val lines = prior.rank(position, position.legalMoves())
        assertTrue("Prior returned no candidates", lines.isNotEmpty())
        assertTrue("Prior should score all legal start moves", lines.size == position.legalMoves().size)
        assertTrue("Top Prior score must be finite", lines.first().policyScore.isFinite())
    }

    @Test
    fun stockfishPayloadIsPresentForDeviceAbi() {
        val lib = java.io.File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")
        assertTrue("Stockfish payload missing: ${lib.absolutePath}", lib.isFile && lib.length() > 1_000_000)
    }

    @Test
    fun stockfishVerifierStartsAndMeasuresNodes() {
        val sf = StockfishProcess(context)
        try {
            sf.start().getOrThrow()
            val r = sf.verify(ChessPosition.START_FEN, "e2e4", 20_000)
            assertTrue("Stockfish did not report measured nodes: ${r.nodes}", r.nodes > 0)
            assertTrue("Stockfish did not report depth: ${r.depth}", r.depth > 0)
            assertTrue("searchmoves returned a different move: ${r.move}", r.move == "e2e4")
        } finally {
            sf.close()
        }
    }

    @Test
    fun fullBmcSearchReturnsVerifiedCandidates() {
        val search = BmcSearch(context)
        try {
            search.load().getOrThrow()
            val results = search.analyze(ChessPosition.START_FEN, 80_000, 4)
            assertTrue("BMC search returned no candidates", results.isNotEmpty())
            assertTrue("BMC search returned too many candidates", results.size <= 4)
            assertTrue("No candidate has measured Stockfish nodes", results.any { it.nodes > 0 })
        } finally {
            search.close()
        }
    }
}
