package com.brilliantmax.chess

import android.content.Context

class PriorEngine(context:Context) {
    private val runtime=ModelRuntime(context.applicationContext)
    fun load()=runtime.load()
    fun loaded()=runtime.isLoaded()
    fun rank(position:ChessPosition, moves:List<ChessMove>):List<ModelRuntime.PriorLine> = runtime.analyze(position,moves)
}
