package com.brilliantmax.chess

/** Small, deterministic board model used for FEN decoding, move application and
 * creative-structure audits. Stockfish remains the legality authority. */
class FenBoard private constructor(
    val squares: CharArray,
    var whiteToMove: Boolean,
    var castling: String,
    var ep: Int,
    var halfmove: Int,
    var fullmove: Int
) {
    companion object {
        fun start(): FenBoard = fromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
        fun fromFen(fen: String): FenBoard {
            val p = fen.trim().split(Regex("\\s+"))
            require(p.size >= 4) { "Invalid FEN: $fen" }
            val board = CharArray(64) { '.' }
            var idx = 0
            for (ch in p[0]) {
                when {
                    ch == '/' -> Unit
                    ch.isDigit() -> idx += ch.digitToInt()
                    else -> { require(idx < 64); board[idx++] = ch }
                }
            }
            require(idx == 64) { "Invalid FEN board" }
            val ep = if (p[3] == "-") -1 else square(p[3])
            return FenBoard(board, p[1] == "w", if (p[2] == "-") "" else p[2], ep,
                p.getOrNull(4)?.toIntOrNull() ?: 0, p.getOrNull(5)?.toIntOrNull() ?: 1)
        }
        fun square(s: String): Int = (8 - s[1].digitToInt()) * 8 + (s[0] - 'a')
        fun name(i: Int): String = "${('a'.code + i % 8).toChar()}${8 - i / 8}"
    }

    fun copy(): FenBoard = FenBoard(squares.copyOf(), whiteToMove, castling, ep, halfmove, fullmove)

    fun fen(): String {
        val sb = StringBuilder()
        for (r in 0 until 8) {
            var empty = 0
            for (f in 0 until 8) {
                val c = squares[r * 8 + f]
                if (c == '.') empty++ else { if (empty > 0) { sb.append(empty); empty = 0 }; sb.append(c) }
            }
            if (empty > 0) sb.append(empty)
            if (r != 7) sb.append('/')
        }
        sb.append(if (whiteToMove) " w " else " b ")
        sb.append(if (castling.isEmpty()) "-" else castling)
        sb.append(' ')
        sb.append(if (ep < 0) "-" else name(ep))
        sb.append(" $halfmove $fullmove")
        return sb.toString()
    }

    fun apply(uci: String): FenBoard {
        require(uci.length >= 4) { "Bad UCI move: $uci" }
        val from = square(uci.substring(0, 2)); val to = square(uci.substring(2, 4))
        val moving = squares[from]
        val target = squares[to]
        val capture = target != '.' || (moving.lowercaseChar() == 'p' && to == ep && from % 8 != to % 8)
        squares[from] = '.'
        if (moving.lowercaseChar() == 'p' && to == ep && target == '.') {
            val cap = if (moving.isUpperCase()) to + 8 else to - 8
            if (cap in 0..63) squares[cap] = '.'
        }
        var placed = moving
        if (uci.length >= 5) {
            placed = when (uci[4].lowercaseChar()) { 'q' -> 'q'; 'r' -> 'r'; 'b' -> 'b'; 'n' -> 'n'; else -> moving.lowercaseChar() }
            if (moving.isUpperCase()) placed = placed.uppercaseChar()
        }
        squares[to] = placed
        // Castling rook moves.
        if (moving == 'K' && from == square("e1") && to == square("g1")) { squares[square("h1")] = '.'; squares[square("f1")] = 'R' }
        if (moving == 'K' && from == square("e1") && to == square("c1")) { squares[square("a1")] = '.'; squares[square("d1")] = 'R' }
        if (moving == 'k' && from == square("e8") && to == square("g8")) { squares[square("h8")] = '.'; squares[square("f8")] = 'r' }
        if (moving == 'k' && from == square("e8") && to == square("c8")) { squares[square("a8")] = '.'; squares[square("d8")] = 'r' }
        castling = updateCastling(castling, moving, from, to, target)
        ep = -1
        if (moving.lowercaseChar() == 'p' && kotlin.math.abs(to - from) == 16) ep = (to + from) / 2
        if (moving.lowercaseChar() == 'p' || capture) halfmove = 0 else halfmove++
        if (!whiteToMove) fullmove++
        whiteToMove = !whiteToMove
        return this
    }

    private fun updateCastling(c: String, moving: Char, from: Int, to: Int, captured: Char): String {
        val out = c.toSet().toMutableSet()
        fun remove(ch: Char) { out.remove(ch) }
        when (moving) {
            'K' -> { remove('K'); remove('Q') }
            'k' -> { remove('k'); remove('q') }
            'R' -> { if (from == square("h1")) remove('K'); if (from == square("a1")) remove('Q') }
            'r' -> { if (from == square("h8")) remove('k'); if (from == square("a8")) remove('q') }
        }
        when (captured) {
            'R' -> { if (to == square("h1")) remove('K'); if (to == square("a1")) remove('Q') }
            'r' -> { if (to == square("h8")) remove('k'); if (to == square("a8")) remove('q') }
        }
        return "KQkq".filter { it in out }
    }

    fun materialWhiteMinusBlack(): Int {
        val v = mapOf('p' to 100, 'n' to 320, 'b' to 330, 'r' to 500, 'q' to 900, 'k' to 0)
        return squares.sumOf { c -> if (c == '.') 0 else if (c.isUpperCase()) v[c.lowercaseChar()] ?: 0 else -(v[c] ?: 0) }
    }

    fun isAttacked(target: Int, byWhite: Boolean): Boolean {
        fun own(c: Char) = if (byWhite) c.isUpperCase() else c.isLowerCase()
        val tf = target % 8; val tr = target / 8
        // pawns
        val pawn = if (byWhite) 'P' else 'p'
        val pr = if (byWhite) tr + 1 else tr - 1
        for (df in intArrayOf(-1, 1)) { val f = tf + df; if (f in 0..7 && pr in 0..7 && squares[pr * 8 + f] == pawn) return true }
        val knight = if (byWhite) 'N' else 'n'
        for ((df, dr) in arrayOf(intArrayOf(1,2),intArrayOf(2,1),intArrayOf(-1,2),intArrayOf(-2,1),intArrayOf(1,-2),intArrayOf(2,-1),intArrayOf(-1,-2),intArrayOf(-2,-1))) { val f=tf+df; val r=tr+dr; if(f in 0..7&&r in 0..7&&squares[r*8+f]==knight)return true }
        val king = if (byWhite) 'K' else 'k'
        for(df in -1..1)for(dr in -1..1)if(df!=0||dr!=0){val f=tf+df;val r=tr+dr;if(f in 0..7&&r in 0..7&&squares[r*8+f]==king)return true}
        fun ray(dF:Int,dR:Int, pieces:Set<Char>):Boolean { var f=tf+dF;var r=tr+dR;while(f in 0..7&&r in 0..7){val c=squares[r*8+f];if(c!='.'){return c in pieces&&own(c)};f+=dF;r+=dR};return false }
        if(ray(1,0,setOf('R','Q','r','q'))||ray(-1,0,setOf('R','Q','r','q'))||ray(0,1,setOf('R','Q','r','q'))||ray(0,-1,setOf('R','Q','r','q')))return true
        if(ray(1,1,setOf('B','Q','b','q'))||ray(-1,1,setOf('B','Q','b','q'))||ray(1,-1,setOf('B','Q','b','q'))||ray(-1,-1,setOf('B','Q','b','q')))return true
        return false
    }

    data class SacrificeAudit(val offer: Boolean, val accepted: Boolean, val materialSwing: Int)

    fun auditSacrifice(candidate: String, pv: List<String>): SacrificeAudit {
        val before = copy(); val from = square(candidate.substring(0,2)); val to = square(candidate.substring(2,4)); val moving = squares[from]
        val after = copy().apply(candidate)
        val offer = moving.lowercaseChar() != 'p' && after.isAttacked(to, !before.whiteToMove)
        val materialSwing = after.materialWhiteMinusBlack() - before.materialWhiteMinusBlack()
        var accepted = false
        var b = after.copy()
        for (m in pv.take(4)) {
            if (m.length < 4) continue
            val mt = square(m.substring(2,4))
            if (mt == to && b.squares[mt] != '.') accepted = true
            b.apply(m)
        }
        return SacrificeAudit(offer, accepted, materialSwing)
    }
}
