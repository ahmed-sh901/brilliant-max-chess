package com.brilliantmax.chess

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class ChessBoardView @JvmOverloads constructor(context:Context,attrs:AttributeSet?=null):View(context,attrs){
    private val light=Color.rgb(238,238,210);private val dark=Color.rgb(118,150,86);private val selected=Color.rgb(245,220,80)
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG);private var position=ChessPosition.start();private var selectedSq=-1
    var onMove:((ChessMove)->Unit)?=null
    fun setPosition(p:ChessPosition){position=p;selectedSq=-1;invalidate()}
    override fun onDraw(c:Canvas){super.onDraw(c);val s=width/8f;paint.typeface=Typeface.create("sans",Typeface.NORMAL)
        for(r in 0 until 8)for(f in 0 until 8){val x=f*s;val y=r*s;paint.color=if((r+f)%2==0)light else dark;c.drawRect(x,y,x+s,y+s,paint);val sq=r*8+f
            if(sq==selectedSq){paint.color=selected;paint.alpha=150;c.drawRect(x,y,x+s,y+s,paint);paint.alpha=255}
            val p=position.board[sq];if(p!=0){paint.color=if(Piece.color(p)==0)Color.WHITE else Color.BLACK;paint.textSize=s*.72f;paint.textAlign=Paint.Align.CENTER;val fm=paint.fontMetrics;val base=y+s/2f-(fm.ascent+fm.descent)/2f;c.drawText(symbol(p),x+s/2f,base,paint)} }
    }
    override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action!=MotionEvent.ACTION_UP)return true;val s=width/8f;val f=(e.x/s).toInt().coerceIn(0,7);val r=(e.y/s).toInt().coerceIn(0,7);val sq=r*8+f
        if(selectedSq<0){if(position.board[sq]!=0&&Piece.color(position.board[sq])==if(position.whiteToMove)0 else 1){selectedSq=sq;invalidate()}}else{
            val candidates=position.legalMoves().filter{it.from==selectedSq&&it.to==sq};if(candidates.isNotEmpty()){val move=candidates.firstOrNull{it.promotion==5}?:candidates.first();onMove?.invoke(move)};selectedSq=-1;invalidate()
        };return true}
    private fun symbol(p:Int)=when(p){Piece.WP->"♙";Piece.WN->"♘";Piece.WB->"♗";Piece.WR->"♖";Piece.WQ->"♕";Piece.WK->"♔";Piece.BP->"♟";Piece.BN->"♞";Piece.BB->"♝";Piece.BR->"♜";Piece.BQ->"♛";Piece.BK->"♚";else->""}
}
