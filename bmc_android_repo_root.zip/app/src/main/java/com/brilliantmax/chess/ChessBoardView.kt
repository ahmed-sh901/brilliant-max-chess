package com.brilliantmax.chess

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class ChessBoardView @JvmOverloads constructor(context: Context, attrs: AttributeSet?=null):View(context,attrs){
    private val light=Color.rgb(238,238,210);private val dark=Color.rgb(118,150,86);private val selected=Color.rgb(245,220,80);private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private var selectedSq=-1;private var board=FenBoard.start();private var legal=emptyList<String>();var onMove:((String)->Unit)?=null
    fun setPosition(fen:String){board=FenBoard.fromFen(fen);selectedSq=-1;invalidate()}
    fun setLegalMoves(moves:List<String>){legal=moves;invalidate()}
    override fun onDraw(c:Canvas){super.onDraw(c);val s=width/8f;for(rank in 0 until 8)for(file in 0 until 8){val x=file*s;val y=rank*s;p.color=if((file+rank)%2==0)light else dark;c.drawRect(x,y,x+s,y+s,p);val sq=rank*8+file;if(sq==selectedSq){p.color=selected;p.alpha=150;c.drawRect(x,y,x+s,y+s,p);p.alpha=255};val ch=board.squares[sq];if(ch!='.'){p.color=if(ch.isUpperCase())Color.WHITE else Color.BLACK;p.textSize=s*.72f;p.textAlign=Paint.Align.CENTER;val fm=p.fontMetrics;c.drawText(pieceGlyph(ch),x+s/2f,y+s/2f-(fm.ascent+fm.descent)/2f,p)}}}
    private fun pieceGlyph(c:Char)=when(c){'K'->"♔";'Q'->"♕";'R'->"♖";'B'->"♗";'N'->"♘";'P'->"♙";'k'->"♚";'q'->"♛";'r'->"♜";'b'->"♝";'n'->"♞";'p'->"♟";else->""}
    override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action==MotionEvent.ACTION_UP){val s=width/8f;val sq=(e.y/s).toInt().coerceIn(0,7)*8+(e.x/s).toInt().coerceIn(0,7);if(selectedSq<0){if(board.squares[sq]!='.')selectedSq=sq}else{val from=selectedSq;selectedSq=-1;val matches=legal.filter{FenBoard.square(it.substring(0,2))==from&&FenBoard.square(it.substring(2,4))==sq};if(matches.isNotEmpty())onMove?.invoke(matches.first{it.length<5||it.endsWith("q")});invalidate()}};return true}
}
