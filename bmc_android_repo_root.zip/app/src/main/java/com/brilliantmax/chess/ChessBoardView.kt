package com.brilliantmax.chess

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class ChessBoardView @JvmOverloads constructor(context:Context,attrs:AttributeSet?=null):View(context,attrs){
    private val light=Color.rgb(238,238,210);private val dark=Color.rgb(118,150,86);private val selected=Color.rgb(245,220,80)
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG);private var selectedSq=-1;private var position=ChessPosition.start()
    var onMove:((ChessMove)->Unit)?=null
    fun setPosition(p:ChessPosition){position=p.copy();selectedSq=-1;invalidate()}
    fun getPosition()=position.copy()
    override fun onDraw(c:Canvas){super.onDraw(c);val s=width/8f
        for(rank in 0 until 8)for(file in 0 until 8){val sq=rank*8+file;val x=file*s;val y=rank*s;paint.color=if((file+rank)%2==0)light else dark;c.drawRect(x,y,x+s,y+s,paint);if(sq==selectedSq){paint.color=selected;paint.alpha=150;c.drawRect(x,y,x+s,y+s,paint);paint.alpha=255};val pc=position.board[sq];if(pc!=0){paint.color=if(pc<=6)Color.WHITE else Color.BLACK;paint.textSize=s*.72f;paint.textAlign=Paint.Align.CENTER;paint.typeface=Typeface.create("sans",Typeface.NORMAL);val fm=paint.fontMetrics;c.drawText(symbol(pc),x+s/2f,y+s/2f-(fm.ascent+fm.descent)/2f,paint)}}
    }
    private fun symbol(p:Int)=when(p){1->"♙";2->"♘";3->"♗";4->"♖";5->"♕";6->"♔";7->"♟";8->"♞";9->"♝";10->"♜";11->"♛";12->"♚";else->""}
    override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action!=MotionEvent.ACTION_UP)return true;val s=width/8f;val f=(e.x/s).toInt().coerceIn(0,7);val r=(e.y/s).toInt().coerceIn(0,7);val sq=r*8+f
        if(selectedSq<0){if(position.board[sq]!=0&&((position.board[sq]<=6)==position.whiteToMove)){selectedSq=sq;invalidate()}}
        else{val from=selectedSq;selectedSq=-1;val candidates=position.legalMoves().filter{it.from==from&&it.to==sq};if(candidates.isNotEmpty())onMove?.invoke(candidates.firstOrNull{it.promotion==5}?:candidates.first());invalidate()};return true}
}
