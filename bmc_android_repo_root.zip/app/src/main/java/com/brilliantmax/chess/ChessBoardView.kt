package com.brilliantmax.chess

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class ChessBoardView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val light = Color.rgb(238,238,210)
    private val dark = Color.rgb(118,150,86)
    private val selected = Color.rgb(245,220,80)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var selectedSq = -1
    var onMove: ((Int,Int)->Unit)? = null

    // Unicode pieces keep the UI functional before the final sprite atlas is bundled.
    private val glyph = arrayOf(
        "♙","♘","♗","♖","♕","♔","♟","♞","♝","♜","♛","♚"
    )

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = width / 8f
        p.typeface=Typeface.create("sans",Typeface.NORMAL)
        for (rank in 0 until 8) for (file in 0 until 8) {
            val x=file*s; val y=rank*s
            p.color=if ((file+rank)%2==0) light else dark
            c.drawRect(x,y,x+s,y+s,p)
            val sq=(7-rank)*8+file
            if(sq==selectedSq){p.color=selected;p.alpha=150;c.drawRect(x,y,x+s,y+s,p);p.alpha=255}
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if(e.action==MotionEvent.ACTION_UP){
            val s=width/8f
            val file=(e.x/s).toInt().coerceIn(0,7)
            val rank=7-(e.y/s).toInt().coerceIn(0,7)
            val sq=rank*8+file
            if(selectedSq<0){selectedSq=sq;invalidate()}
            else {val from=selectedSq;selectedSq=-1;invalidate();onMove?.invoke(from,sq)}
        }
        return true
    }
}
