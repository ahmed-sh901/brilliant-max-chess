package com.brilliantmax.chess

/** Full BMC orchestration: legal moves -> creative Prior -> equal-node verification -> structural audits. */
class AnalysisEngine(private val prior: ModelRuntime, private val sf: StockfishProcess) : AutoCloseable {
    data class Result(val fen:String,val baseline:StockfishProcess.SearchResult,val lines:List<VerifiedLine>,val legalCount:Int,val elapsedMs:Long)
    data class VerifiedLine(val move:String,val priorScore:Float,val creative:Float,val scoreCp:Int?,val mate:Int?,val nodes:Long,val lossCp:Int?,val sound:Boolean,val sacrificeOffer:Boolean,val sacrificeAccepted:Boolean,val responseReduction:Float,val pv:List<String>)

    fun analyze(fen:String,nodesPerCandidate:Long=100_000,candidateCount:Int=16):Result {
        val t=System.currentTimeMillis(); val legal=sf.legalMoves(fen); require(legal.isNotEmpty()){"No legal moves"}
        val ranked=prior.rank(fen,legal); val baseline=sf.search(fen,nodesPerCandidate)
        val baseNum=numeric(baseline)
        val chosen=ranked.take(candidateCount.coerceIn(1,legal.size)); val before=legal.size.toFloat()
        val lines=chosen.map { p ->
            val r=sf.search(fen,nodesPerCandidate,p.move); val afterFen=FenBoard.fromFen(fen).apply(p.move).fen(); val afterCount=sf.legalMoves(afterFen).size.toFloat(); val reduction=((before-afterCount)/before).coerceIn(0f,1f)
            val audit=FenBoard.fromFen(fen).auditSacrifice(p.move,r.pv); val loss=if(baseNum!=null&&numeric(r)!=null) (baseNum-numeric(r)!!).coerceAtLeast(0) else null
            val sound=when { baseline.mate!=null -> r.mate!=null && (r.mate!! >= baseline.mate!!); r.mate!=null -> r.mate!! > 0 || (numeric(r) ?: -100000) >= (baseNum ?: -100000)-80; else -> (numeric(r) ?: -100000) >= (baseNum ?: -100000)-80 }
            VerifiedLine(p.move,p.policyScore,p.probabilities[6],r.scoreCp,r.mate,r.nodes,loss,sound,audit.offer,audit.accepted,reduction,r.pv)
        }.sortedWith(compareByDescending<VerifiedLine>{it.sound}.thenByDescending{it.creative}.thenByDescending{it.responseReduction}.thenByDescending{it.scoreCp?:-100000})
        return Result(fen,baseline,lines,legal.size,System.currentTimeMillis()-t)
    }
    private fun numeric(r:StockfishProcess.SearchResult):Int?=when{r.mate!=null->if(r.mate!!>0)100000-r.mate!!*1000 else -100000-r.mate!!*1000;r.scoreCp!=null->r.scoreCp;else->null}
    override fun close(){sf.close()}
}
