package com.brilliantmax.chess

import android.content.Context
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.TimeUnit

/** Persistent UCI Stockfish 19 process. The binary is produced by CI for arm64
 * and bundled as an Android asset; no network access is required at runtime. */
class StockfishProcess(private val context: Context) : AutoCloseable {
    companion object { private const val ASSET = "stockfish-arm64" }
    data class SearchResult(val scoreCp: Int?, val mate: Int?, val nodes: Long, val bestMove: String, val pv: List<String>)
    private var process: Process? = null
    private var writer: OutputStreamWriter? = null
    private var reader: BufferedReader? = null

    @Synchronized fun start() {
        if (process?.isAlive == true) return
        val exe = extractBinary()
        process = ProcessBuilder(exe.absolutePath).redirectErrorStream(true).start()
        writer = OutputStreamWriter(process!!.outputStream)
        reader = BufferedReader(InputStreamReader(process!!.inputStream))
        send("uci"); await("uciok", 10_000)
        send("setoption name Threads value 1")
        send("setoption name Hash value 64")
        send("isready"); await("readyok", 10_000)
    }

    @Synchronized fun legalMoves(fen: String): List<String> {
        start(); send("position fen $fen"); send("go perft 1")
        val moves = mutableListOf<String>()
        while (true) {
            val line = reader!!.readLine() ?: error("Stockfish exited during perft")
            if (line.startsWith("Nodes searched:")) break
            val token = line.substringBefore(':').trim()
            if (Regex("^[a-h][1-8][a-h][1-8][qrbn]?$", RegexOption.IGNORE_CASE).matches(token)) moves += token.lowercase()
        }
        send("isready"); await("readyok", 10_000)
        return moves.distinct()
    }

    @Synchronized fun search(fen: String, nodes: Long, searchMove: String? = null): SearchResult {
        start(); send("position fen $fen")
        val cmd = buildString { append("go nodes "); append(nodes.coerceIn(1L, 50_000_000L)); if (!searchMove.isNullOrBlank()) append(" searchmoves ").append(searchMove) }
        send(cmd)
        var score: Int? = null; var mate: Int? = null; var seenNodes = 0L; var pv = emptyList<String>(); var best = ""
        while (true) {
            val line = reader!!.readLine() ?: error("Stockfish exited during search")
            if (line.startsWith("info ")) {
                Regex("\\bnodes (\\d+)").find(line)?.groupValues?.get(1)?.toLongOrNull()?.let { seenNodes = maxOf(seenNodes, it) }
                val sm = Regex("\\bscore cp (-?\\d+)").find(line); if (sm != null) { score = sm.groupValues[1].toInt(); mate = null }
                val mm = Regex("\\bscore mate (-?\\d+)").find(line); if (mm != null) { mate = mm.groupValues[1].toInt(); score = null }
                val p = Regex("\\bpv (.+)$").find(line)?.groupValues?.get(1); if (p != null) pv = p.trim().split(Regex("\\s+"))
            } else if (line.startsWith("bestmove ")) { best = line.split(' ')[1]; break }
        }
        send("isready"); await("readyok", 10_000)
        return SearchResult(score, mate, seenNodes, best, pv)
    }

    private fun send(s: String) { writer!!.apply { write(s); write("\n"); flush() } }
    private fun await(expected: String, timeoutMs: Long) {
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs)
        while (System.nanoTime() < deadline) { val line = reader!!.readLine() ?: error("Stockfish exited while waiting for $expected"); if (line.trim() == expected) return }
        error("Timed out waiting for $expected")
    }

    private fun extractBinary(): File {
        val dir = File(context.filesDir, "engine").apply { mkdirs() }
        val out = File(dir, ASSET)
        if (!out.exists() || out.length() < 100_000L) {
            context.assets.open(ASSET).use { input -> out.outputStream().use { output -> input.copyTo(output) } }
        }
        require(out.setExecutable(true, false)) { "Could not mark Stockfish executable" }
        return out
    }

    override fun close() { try { writer?.let { it.write("quit\n"); it.flush() } } catch (_: Throwable) {}; try { process?.waitFor(500, TimeUnit.MILLISECONDS) } catch (_: Throwable) {}; process?.destroy(); process = null; reader = null; writer = null }
}
