package com.brilliantmax.chess

import android.content.Context
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.TimeUnit

/** Persistent UCI bridge to an arm64 Stockfish 19 binary built by CI.
 * The binary is intentionally packaged as a native-library payload and executed
 * directly; no GUI/engine state is duplicated in Kotlin.
 */
class StockfishProcess(private val context: Context) : AutoCloseable {
    data class Result(val move:String,val scoreCp:Int?,val mate:Int?,val depth:Int,val nodes:Long,val pv:List<String>,val elapsedMs:Long)
    private var process:Process?=null
    private var input:BufferedReader?=null
    private var output:BufferedWriter?=null
    private val lock=Any()

    @Synchronized fun start():Result<Unit> = runCatching {
        if(process?.isAlive==true) return@runCatching Unit
        val bin=File(context.applicationInfo.nativeLibraryDir,"libstockfish.so")
        require(bin.exists()) { "Stockfish binary missing: ${bin.absolutePath}" }
        val nnue=copyAsset("stockfish_nnue.nnue")
        process=ProcessBuilder(bin.absolutePath).redirectErrorStream(true).start()
        input=BufferedReader(InputStreamReader(process!!.inputStream))
        output=BufferedWriter(OutputStreamWriter(process!!.outputStream))
        command("uci", "uciok")
        send("setoption name Threads value 1")
        send("setoption name Hash value 32")
        send("setoption name EvalFile value ${nnue.absolutePath}")
        command("isready", "readyok")
    }

    fun verify(fen:String, move:String, nodes:Long):Result {
        synchronized(lock) {
            start().getOrThrow()
            val t0=System.nanoTime()
            send("position fen $fen")
            command("isready", "readyok")
            send("go nodes ${nodes.coerceAtLeast(1000)} searchmoves $move")
            var best=move; var cp:Int?=null; var mate:Int?=null; var depth=0; var measured=0L; var pv=emptyList<String>()
            while(true){
                val line=input!!.readLine() ?: error("Stockfish terminated unexpectedly")
                if(line.startsWith("info ")){
                    val tok=line.trim().split(Regex("\\s+"))
                    fun value(key:String):String? { val i=tok.indexOf(key); return if(i>=0&&i+1<tok.size)tok[i+1] else null }
                    value("depth")?.toIntOrNull()?.let{depth=maxOf(depth,it)}
                    value("nodes")?.toLongOrNull()?.let{measured=maxOf(measured,it)}
                    val si=tok.indexOf("score")
                    if(si>=0&&si+2<tok.size){
                        when(tok[si+1]){"cp"->{cp=tok[si+2].toIntOrNull();mate=null};"mate"->{mate=tok[si+2].toIntOrNull();cp=null}}
                    }
                    val pi=tok.indexOf("pv"); if(pi>=0)pv=tok.drop(pi+1)
                } else if(line.startsWith("bestmove ")){
                    val parts=line.trim().split(Regex("\\s+")); if(parts.size>=2)best=parts[1]; break
                }
            }
            return Result(best,cp,mate,depth,measured,pv,(System.nanoTime()-t0)/1_000_000)
        }
    }

    private fun send(s:String){ output!!.write(s);output!!.newLine();output!!.flush() }
    private fun command(cmd:String,needle:String){
        send(cmd)
        while(true){val l=input!!.readLine()?:error("Stockfish closed while waiting for $needle");if(l.contains(needle))return}
    }
    private fun copyAsset(name:String):File {
        val f=File(context.filesDir,name)
        if(!f.exists()||f.length()==0L)context.assets.open(name).use{inp->f.outputStream().use{out->inp.copyTo(out)}}
        return f
    }
    override fun close(){ synchronized(lock){runCatching{send("quit")};runCatching{input?.close()};runCatching{output?.close()};runCatching{process?.destroy()};runCatching{process?.waitFor(500,TimeUnit.MILLISECONDS)};process=null} }
}
