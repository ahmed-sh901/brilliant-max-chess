package com.brilliantmax.chess

object NativeStockfish {
    init { System.loadLibrary("brilliantmax") }
    external fun nativeInit(networkDir:String):Boolean
    external fun nativeVerify(fen:String,candidates:Array<String>,totalNodes:Long):String
    external fun nativeStop()
    external fun nativeClose()
}
