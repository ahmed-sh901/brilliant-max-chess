package com.brilliantmax.chess

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity:AppCompatActivity(){
    private lateinit var board:ChessBoardView;private lateinit var status:TextView;private lateinit var details:TextView;private lateinit var fenInput:EditText;private lateinit var analysis:AnalysisController
    private var fen=FenBoard.start().fen()
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);analysis=AnalysisController(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,10,10,10)}
        board=ChessBoardView(this);root.addView(board,LinearLayout.LayoutParams(-1,0,1f))
        status=TextView(this).apply{text="BMC 2.0 • loading runtime…";textSize=15f;gravity=Gravity.CENTER_VERTICAL};root.addView(status,LinearLayout.LayoutParams(-1,48))
        fenInput=EditText(this).apply{setText(fen);setSingleLine(true);hint="FEN";textSize=12f};root.addView(fenInput,LinearLayout.LayoutParams(-1,52))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};val load=Button(this).apply{text="SET FEN"};val analyze=Button(this).apply{text="ANALYZE"};val stop=Button(this).apply{text="STOP"};row.addView(load,LinearLayout.LayoutParams(0,54,1f));row.addView(analyze,LinearLayout.LayoutParams(0,54,1f));row.addView(stop,LinearLayout.LayoutParams(0,54,1f));root.addView(row)
        details=TextView(this).apply{textSize=13f;setPadding(4,4,4,4)};root.addView(ScrollView(this).apply{addView(details)},LinearLayout.LayoutParams(-1,210))
        setContentView(root);board.setPosition(fen)
        Thread{val r=analysis.load();runOnUiThread{if(r.isSuccess){status.text="BMC 2.0 • Prior + Stockfish runtime ready ✓";details.text="v1.52 Prior • Stockfish 19 • equal-node verifier";refreshLegal()}else{status.text="Runtime load failed";details.text=r.exceptionOrNull()?.stackTraceToString()?.take(2200)?:"Unknown error"}}}.start()
        load.setOnClickListener{try{fen=FenBoard.fromFen(fenInput.text.toString()).fen();board.setPosition(fen);refreshLegal();status.text="Position loaded";details.text="Legal position ready for BMC analysis."}catch(t:Throwable){status.text="Invalid FEN";details.text=t.message?:("Invalid FEN")}}
        board.onMove={move->try{fen=FenBoard.fromFen(fen).apply(move).fen();fenInput.setText(fen);board.setPosition(fen);refreshLegal();status.text="Played $move"}catch(t:Throwable){details.text=t.stackTraceToString().take(1600)}}
        analyze.setOnClickListener{if(!analysis.loaded()){status.text="Runtime is not loaded";return@setOnClickListener};status.text="BMC search running…";details.text="Prior ranking → Stockfish equal-node verification…";analysis.analyze(fen,100_000,16){result,error->runOnUiThread{if(error!=null){status.text="Analysis failed";details.text=error.stackTraceToString().take(3000)}else{status.text="BMC complete • ${result!!.elapsedMs} ms • ${result.legalCount} legal moves";details.text=render(result)}}}}
        stop.setOnClickListener{status.text="Stop requested (current bounded search completes)"}
    }
    private fun refreshLegal(){Thread{try{val m=analysis.legalMoves(fen);runOnUiThread{board.setLegalMoves(m)}}catch(_:Throwable){}}.start()}
    private fun render(r:AnalysisEngine.Result):String{val base=r.baseline.let{it.mate?.let{"mate $it"}?:"cp ${it.scoreCp?:"?"}"};return buildString{append("Baseline: $base • nodes=${r.baseline.nodes}\n\n");r.lines.forEachIndexed{i,x->append("${i+1}. ${x.move}  ");append("prior=${"%.3f".format(x.priorScore)} creative=${"%.3f".format(x.creative)} ");append(if(x.sound)"SOUND"else"UNSOUND");if(x.sacrificeOffer)append(" • sac-offer");if(x.sacrificeAccepted)append(" • accepted");append(" • constraint=${"%.2f".format(x.responseReduction)}");if(x.lossCp!=null)append(" • loss=${x.lossCp}cp");append(" • nodes=${x.nodes}\n");if(x.pv.isNotEmpty())append("   PV: ${x.pv.take(6).joinToString(" ")}\n")};append("\nVerified creative discoveries are gated by Stockfish; the Prior alone never declares a move brilliant.")}}
    override fun onDestroy(){analysis.close();super.onDestroy()}
}
