package com.brilliantmax.chess

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var board: ChessBoardView
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var analysis: AnalysisController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        analysis = AnalysisController(this)

        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(12,12,12,12)
        }
        board=ChessBoardView(this)
        root.addView(board,LinearLayout.LayoutParams(-1,0,1f))

        status=TextView(this).apply {
            text="Brilliant-Max • loading Prior runtime…"
            textSize=15f
            gravity=Gravity.CENTER_VERTICAL
        }
        root.addView(status,LinearLayout.LayoutParams(-1,52))

        details=TextView(this).apply {
            textSize=14f
            setPadding(8,4,8,4)
        }
        root.addView(details,LinearLayout.LayoutParams(-1,140))

        val controls=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val analyze=Button(this).apply { text="ANALYZE" }
        val stop=Button(this).apply { text="STOP" }
        controls.addView(analyze,LinearLayout.LayoutParams(0,56,1f))
        controls.addView(stop,LinearLayout.LayoutParams(0,56,1f))
        root.addView(controls)

        setContentView(root)

        Thread {
            val result = analysis.loadModel()
            runOnUiThread {
                if (result.isSuccess) {
                    status.text="Brilliant-Max • Prior runtime loaded ✓"
                    details.text="TorchScript v1.52 • 7 heads • CPU smoke test ready"
                } else {
                    status.text="Prior runtime failed to load"
                    details.text=result.exceptionOrNull()?.stackTraceToString()?.take(1400) ?: "Unknown load error"
                }
            }
        }.start()

        analyze.setOnClickListener {
            if (!analysis.isModelLoaded()) {
                status.text="Prior runtime is not loaded"
                return@setOnClickListener
            }
            status.text="Running Prior • start position"
            details.text="Inference running…"
            analysis.start { lines, ms, error ->
                runOnUiThread {
                    if (error != null) {
                        status.text="Prior inference failed"
                        details.text=error.stackTraceToString().take(1800)
                    } else {
                        status.text="Prior inference complete • ${ms} ms"
                        details.text=lines.mapIndexed { i, x ->
                            "${i+1}. ${x.move}  score=${"%.3f".format(x.policyScore)}  creative=${"%.3f".format(x.probabilities[6])}"
                        }.joinToString("\n") +
                            "\n\nNot verified: Stockfish/search layer is not connected yet."
                    }
                }
            }
        }
        stop.setOnClickListener { analysis.stop();status.text="Stopped" }
    }

    override fun onDestroy(){ analysis.close();super.onDestroy() }
}
