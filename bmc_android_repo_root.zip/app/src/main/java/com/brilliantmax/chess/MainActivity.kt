package com.brilliantmax.chess

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity:AppCompatActivity(){
    private lateinit var board:ChessBoardView;private lateinit var status:TextView;private lateinit var details:TextView;private lateinit var fenInput:EditText
    private lateinit var analysis:AnalysisController;private var position=ChessPosition.start()
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);analysis=AnalysisController(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,10,10,10)}
        board=ChessBoardView(this);root.addView(board,LinearLayout.LayoutParams(-1,0,1f))
        status=TextView(this).apply{text="Brilliant-Max • initializing…";textSize=15f;gravity=Gravity.CENTER_VERTICAL};root.addView(status,LinearLayout.LayoutParams(-1,48))
        val fenRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        fenInput=EditText(this).apply{setSingleLine(true);hint="FEN (optional)";text=ChessPosition.START_FEN;textSize=12f};fenRow.addView(fenInput,LinearLayout.LayoutParams(0,58,1f))
        val load=Button(this).apply{text="LOAD"};fenRow.addView(load,LinearLayout.LayoutParams(110,58));root.addView(fenRow)
        val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};val analyze=Button(this).apply{text="ANALYZE"};val stop=Button(this).apply{text="STOP"};controls.addView(analyze,LinearLayout.LayoutParams(0,58,1f));controls.addView(stop,LinearLayout.LayoutParams(0,58,1f));root.addView(controls)
        details=TextView(this).apply{textSize=13f;setPadding(6,4,6,4);setTextIsSelectable(true)};root.addView(details,LinearLayout.LayoutParams(-1,250));setContentView(root)
        board.onMove={move->position=position.apply(move);fenInput.setText(position.fen());details.text="Move ${move.uci()} • legal replies=${position.legalMoves().size}"}
        load.setOnClickListener{try{position=ChessPosition.fromFen(fenInput.text.toString());board.setPosition(position);status.text=if(analysis.isReady())"BMC • position loaded ✓" else "BMC • position loaded";details.text="Legal moves: ${position.legalMoves().size}"}catch(t:Throwable){status.text="Invalid FEN";details.text=t.message?:"Invalid FEN"}}
        analyze.setOnClickListener{if(!analysis.isReady()){status.text="Runtime not ready";return@setOnClickListener};status.text="BMC • Prior → Stockfish verification…";details.text="Searching candidates…";analysis.start(position,500_000){result->runOnUiThread{if(result.error!=null){status.text="Analysis failed";details.text=result.error.stackTraceToString().take(5000)}else{status.text="BMC • verified ${result.lines.count{it.creative}} creative candidates • ${result.elapsedMs} ms";details.text=buildString{append("Legal moves: ${result.legalMoves}\n\n");result.lines.forEachIndexed{i,l->append("${i+1}. ${l.verification.move}  loss=${l.verification.lossCp}cp  nodes=${l.verification.nodes}  D${l.verification.depth}\n");append("   Prior=${"%.3f".format(l.priorScore)}  sacrifice=${l.sacrificeOffer} accepted=${l.sacrificeAccepted} constraint=${"%.1f".format(l.responseReduction*100)}% sound=${l.sound} creative=${l.creative}\n");append("   PV ${l.verification.pv}\n")}}}}}}
        stop.setOnClickListener{analysis.stop();status.text="Stopped"}
        Thread{val r=analysis.loadAll();runOnUiThread{if(r.isSuccess){status.text="Brilliant-Max • Prior + Stockfish ready ✓";details.text="v1.52 Prior + Stockfish 19 native verifier\n500k-node analysis budget\nNo benchmark claim; runtime smoke test only."}else{status.text="Runtime initialization failed";details.text=r.exceptionOrNull()?.stackTraceToString()?.take(5000)?:"Unknown error"}}}.start()
    }
    override fun onDestroy(){analysis.close();super.onDestroy()}
}
