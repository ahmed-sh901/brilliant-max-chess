package com.brilliantmax.chess

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var board:ChessBoardView
    private lateinit var status:TextView
    private val analysis=AnalysisController()

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(12,12,12,12)
        }
        board=ChessBoardView(this)
        root.addView(board,LinearLayout.LayoutParams(-1,0,1f))

        status=TextView(this).apply {
            text="Brilliant-Max • ready"
            textSize=15f
            gravity=Gravity.CENTER_VERTICAL
        }
        root.addView(status,LinearLayout.LayoutParams(-1,52))

        val controls=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val analyze=Button(this).apply { text="ANALYZE" }
        val stop=Button(this).apply { text="STOP" }
        controls.addView(analyze,LinearLayout.LayoutParams(0,56,1f))
        controls.addView(stop,LinearLayout.LayoutParams(0,56,1f))
        root.addView(controls)

        analyze.setOnClickListener {
            // Start position for the first UI milestone. Board-state/PGN layer
            // will replace this constant when the move model is wired.
            status.text="Analyzing • max device budget"
            analysis.start("startpos", 50_000_000L) { lines, ms ->
                runOnUiThread {
                    status.text=if(lines.isEmpty())
                        "Model runtime not bundled yet"
                    else
                        lines.take(3).joinToString("   "){ "${it.move} ${it.scoreCp}cp D${it.depth}" }
                }
            }
        }
        stop.setOnClickListener { analysis.stop();status.text="Stopped" }
        setContentView(root)
    }

    override fun onDestroy(){ analysis.stop();super.onDestroy() }
}
