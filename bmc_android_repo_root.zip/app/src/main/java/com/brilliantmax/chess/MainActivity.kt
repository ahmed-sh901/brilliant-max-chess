package com.brilliantmax.chess

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity:AppCompatActivity(){
    private lateinit var board:ChessBoardView;private lateinit var status:TextView;private lateinit var details:TextView;private lateinit var analysis:AnalysisController;private var position=ChessPosition.start()
    override fun onCreate(state:Bundle?){super.onCreate(state);analysis=AnalysisController(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,10,10,10)}
        board=ChessBoardView(this);root.addView(board,LinearLayout.LayoutParams(-1,0,1f))
        status=TextView(this).apply{text="Brilliant-Max • initializing…";textSize=15f;gravity=Gravity.CENTER_VERTICAL};root.addView(status,LinearLayout.LayoutParams(-1,52))
        details=TextView(this).apply{textSize=13f;setPadding(6,2,6,2);textIsSelectable=true};root.addView(details,LinearLayout.LayoutParams(-1,190))
        val fenRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val fenInput=EditText(this).apply{setSingleLine(true);hint="Paste FEN";text=position.fen();textSize=12f}
        val loadFen=Button(this).apply{text="LOAD FEN"}
        fenRow.addView(fenInput,LinearLayout.LayoutParams(0,56,1f));fenRow.addView(loadFen,LinearLayout.LayoutParams(-2,56));root.addView(fenRow)
        val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};val analyze=Button(this).apply{text="ANALYZE"};val stop=Button(this).apply{text="STOP"};controls.addView(analyze,LinearLayout.LayoutParams(0,56,1f));controls.addView(stop,LinearLayout.LayoutParams(0,56,1f));root.addView(controls);setContentView(root)
        board.onMove={mv->position.make(mv);fenInput.setText(position.fen());board.setPosition(position);status.text="Position updated • ${mv.uci()}";details.text="${position.fen()}\nLegal moves: ${position.legalMoves().size}"}
        loadFen.setOnClickListener{runCatching{ChessPosition.fromFen(fenInput.text.toString().trim())}.onSuccess{position=it;board.setPosition(position);status.text="FEN loaded • legal position";details.text="${position.fen()}\nLegal moves: ${position.legalMoves().size}"}.onFailure{status.text="Invalid FEN";details.text=it.message?:"FEN parse error"}}
        board.setPosition(position)
        Thread{val r=analysis.load();runOnUiThread{if(r.isSuccess){status.text="Brilliant-Max • Prior + Stockfish ready ✓";details.text="Prior v1.52 • Stockfish 19 verifier • ${position.fen()}\nLegal moves: ${position.legalMoves().size}"}else{status.text="Engine runtime failed";details.text=r.exceptionOrNull()?.stackTraceToString()?.take(2400)?:"Unknown error"}}}.start()
        analyze.setOnClickListener{if(!analysis.isLoaded()){status.text="Engine runtime is not loaded";return@setOnClickListener};val fen=position.fen();status.text="BMC search • Prior → verification";details.text="Searching 8 creative candidates…\n$fen";analysis.start(fen,2_000_000,8){lines,ms,error->runOnUiThread{if(error!=null){status.text="Search failed";details.text=error.stackTraceToString().take(2600)}else{status.text="BMC analysis complete • ${ms} ms";details.text=render(lines,fen)}}}}
        stop.setOnClickListener{analysis.stop();status.text="Stopped"}
    }
    private fun render(xs:List<BmcSearch.Discovery>,fen:String):String=buildString{append(fen).append("\n\n");if(xs.isEmpty())append("No verified candidates returned.") else xs.take(8).forEachIndexed{i,x->append(i+1).append(". ").append(x.move).append("  SF=").append(x.scoreCp?.let{"${it}cp"}?:if(x.mate!=null)"M${x.mate}" else "?").append("  nodes=").append(x.nodes).append(" d=").append(x.depth).append("\n   Prior=").append(fmt(x.prior)).append(" creative=").append(fmt(x.creative)).append(" sacrifice=").append(fmt(x.sacrifice)).append("\n   response reduction=").append(fmt(x.responseReduction*100f)).append("%  brilliantEvidence=").append(fmt(x.brilliantEvidence)).append("  offer=").append(x.sacrificeOffer).append(" accepted=").append(x.acceptedCapture).append(" chain=").append(x.chainLength).append(" sound=").append(x.sound).append("\n   PV: ").append(x.pv.joinToString(" ")).append("\n\n")};append("BMC policy: Prior proposes; Stockfish verifies. No sacrifice is accepted as brilliant by label alone.")}
    private fun fmt(v:Float)=String.format(Locale.US,"%.3f",v)
    override fun onDestroy(){analysis.close();super.onDestroy()}
}
