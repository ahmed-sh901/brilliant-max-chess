package com.brilliantmax.chess

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

class StockfishVerifier(private val context: Context) {
    companion object { private const val NET="nn-1a298aa575a0.nnue" }
    private var ready=false
    fun load():Result<Unit> = runCatching {
        val file=copyAndValidateNetwork()
        check(NativeStockfish.nativeInit(file.parentFile!!.absolutePath)) { "Native Stockfish initialization failed" }
        ready=true
    }
    fun isReady()=ready
    fun verify(fen:String,candidates:List<String>,nodes:Long):List<VerifiedLine>{
        check(ready){"Stockfish verifier is not loaded"}
        val raw=NativeStockfish.nativeVerify(fen,candidates.toTypedArray(),nodes)
        if(raw.startsWith("ERROR\t")) error(raw.substringAfter('\t'))
        return raw.lineSequence().filter{it.isNotBlank()&&!it.startsWith("BASE\t")}.mapNotNull{line->
            val p=line.split('\t',limit=8);if(p.size<8)return@mapNotNull null
            VerifiedLine(p[0],p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toLong(),p[5].toInt(),p[6],p[7])
        }.toList()
    }
    fun stop(){if(ready)NativeStockfish.nativeStop()}
    fun close(){if(ready){NativeStockfish.nativeClose();ready=false}}

    private fun copyAndValidateNetwork():File{
        val out=File(context.filesDir,NET)
        if(!out.exists()||out.length()<1024){context.assets.open(NET).use{input->FileOutputStream(out).use{input.copyTo(it)}}}
        val md=MessageDigest.getInstance("SHA-256");val digest=out.inputStream().use{it.readBytes()};val hash=md.digest(digest).joinToString(""){b->"%02x".format(b.toInt() and 255)}
        check(hash.startsWith(NET.removePrefix("nn-").removeSuffix(".nnue"))){"NNUE checksum mismatch"}
        return out
    }
    data class VerifiedLine(val move:String,val baselineCp:Int,val candidateCp:Int,val lossCp:Int,val nodes:Long,val depth:Int,val bestmove:String,val pv:String)
}
