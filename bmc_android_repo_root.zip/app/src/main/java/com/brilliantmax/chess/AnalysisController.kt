package com.brilliantmax.chess

import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

data class AnalysisLine(
    val move:String,
    val scoreCp:Int,
    val depth:Int,
    val nodes:Long,
    val creative:Float,
    val sacrifice:Float,
    val constraint:Float,
    val novelty:Float
)

class AnalysisController {
    private val running=AtomicBoolean(false)
    private val pool=Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors().coerceAtMost(8))

    fun start(fen:String, nodeBudget:Long, callback:(List<AnalysisLine>,Long)->Unit) {
        if(!running.compareAndSet(false,true)) return
        pool.execute {
            val start=SystemClock.elapsedRealtime()
            try {
                // Native bridge is deliberately the single search boundary.
                // It will host: board encoding -> Brilliant Prior -> candidate
                // allocation -> native verifier/search -> callback.
                val result=NativeSearch.analyze(fen,nodeBudget)
                callback(result,SystemClock.elapsedRealtime()-start)
            } finally { running.set(false) }
        }
    }
    fun stop(){ NativeSearch.stop(); running.set(false) }
}

object NativeSearch {
    init { try { System.loadLibrary("brilliantmax") } catch(_:Throwable){} }
    external fun analyzeNative(fen:String,budget:Long):Array<AnalysisLine>
    external fun stopNative()

    fun analyze(fen:String,budget:Long):List<AnalysisLine> = try {
        analyzeNative(fen,budget).toList()
    } catch(_:Throwable) { emptyList() }
    fun stop(){ try { stopNative() } catch(_:Throwable){} }
}
