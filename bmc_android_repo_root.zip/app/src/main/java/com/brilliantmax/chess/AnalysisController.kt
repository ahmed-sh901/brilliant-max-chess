package com.brilliantmax.chess

import android.content.Context
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class AnalysisController(context: Context) {
    private val appContext=context.applicationContext
    private val prior=ModelRuntime(appContext)
    private val verifier=StockfishVerifier(appContext)
    private val running=AtomicBoolean(false)
    private val pool=Executors.newSingleThreadExecutor()

    fun loadAll():Result<Unit> = runCatching { prior.load().getOrThrow(); verifier.load().getOrThrow() }
    fun isReady()=prior.isLoaded()&&verifier.isReady()

    fun start(position:ChessPosition,nodes:Long=500_000,callback:(AnalysisResult)->Unit){
        if(!running.compareAndSet(false,true))return
        pool.execute{
            val start=SystemClock.elapsedRealtime()
            try{
                val legal=position.legalMoves()
                val priorLines=prior.analyze(position)
                val verified=verifier.verify(position.fen(),priorLines.map{it.move},nodes)
                val before=legal.size
                val finalLines=verified.mapNotNull{v->
                    val move=legal.firstOrNull{it.uci()==v.move} ?: return@mapNotNull null
                    val after=position.apply(move).legalMoves().size
                    val reduction=if(before==0)0f else ((before-after).toFloat()/before).coerceIn(-1f,1f)
                    val priorLine=priorLines.first{it.move==v.move}
                    val offer=isSacrificeOffer(position,move)
                    val accepted=isAcceptedCapture(position,move,v.pv)
                    val sound=v.lossCp<=80
                    val creative=sound&&(offer||accepted||reduction>=0.25f)
                    VerifiedLine(v,priorLine.policyScore,offer,accepted,reduction,sound,creative)
                }.sortedWith(compareByDescending<VerifiedLine>{it.creative}.thenBy{it.verification.lossCp}.thenByDescending{it.priorScore})
                callback(AnalysisResult(position.fen(),before,finalLines,SystemClock.elapsedRealtime()-start,null))
            }catch(t:Throwable){callback(AnalysisResult(position.fen(),position.legalMoves().size,emptyList(),SystemClock.elapsedRealtime()-start,t))}
            finally{running.set(false)}
        }
    }
    fun stop(){running.set(false);verifier.stop()}
    fun close(){verifier.close();pool.shutdownNow()}

    private fun isSacrificeOffer(pos:ChessPosition,m:ChessMove):Boolean{
        val moving=pos.board[m.from];if(Piece.isPawn(moving)||Piece.isKing(moving))return false
        val after=pos.apply(m);return LegalMoveGenerator.isSquareAttacked(after,m.to,!pos.whiteToMove)
    }

    private fun isAcceptedCapture(pos:ChessPosition,m:ChessMove,pv:String):Boolean{
        val tokens=pv.trim().split(Regex("\\s+")).filter{it.isNotBlank()};if(tokens.isEmpty())return false
        var p=pos
        var first=true
        for((i,u) in tokens.withIndex()){
            val lm=p.legalMoves().firstOrNull{it.uci()==u} ?: break
            if(first){if(lm.uci()!=m.uci())return false;first=false}
            else if(i<=4 && lm.to==m.to)return true
            p=p.apply(lm)
        }
        return false
    }

    data class VerifiedLine(
        val verification:StockfishVerifier.VerifiedLine,
        val priorScore:Float,
        val sacrificeOffer:Boolean,
        val sacrificeAccepted:Boolean,
        val responseReduction:Float,
        val sound:Boolean,
        val creative:Boolean
    )
    data class AnalysisResult(val fen:String,val legalMoves:Int,val lines:List<VerifiedLine>,val elapsedMs:Long,val error:Throwable?)
}
