package com.brilliantmax.chess

import android.content.Context
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

data class AnalysisLine(
    val move:String,
    val scoreCp:Int,
    val depth:Int,
    val nodes:Long,
    val creative:Float,
    val sacrifice:Float,
    val constraint:Float,
    val novelty:Float
)

class AnalysisController(context: Context) : AutoCloseable {
    private val search=BmcSearch(context.applicationContext)
    private val running=AtomicBoolean(false)
    private val pool=Executors.newSingleThreadExecutor()
    private var loaded=false

    fun load():Result<Unit> = search.load().also { loaded=it.isSuccess }
    fun isLoaded()=loaded
    fun start(fen:String,budget:Long=2_000_000,candidates:Int=8,callback:(List<BmcSearch.Discovery>,Long,Throwable?)->Unit){
        if(!running.compareAndSet(false,true))return
        pool.execute{
            val t=SystemClock.elapsedRealtime()
            try{
                val r=runCatching{search.analyze(fen,budget,candidates)}
                callback(r.getOrDefault(emptyList()),SystemClock.elapsedRealtime()-t,r.exceptionOrNull())
            }finally{running.set(false)}
        }
    }
    fun stop(){running.set(false); search.stop()}
    override fun close(){running.set(false);search.close();pool.shutdownNow()}
}
