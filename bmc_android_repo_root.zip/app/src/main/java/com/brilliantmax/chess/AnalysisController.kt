package com.brilliantmax.chess

import android.content.Context
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

data class AnalysisLine(
    val move:String,
    val scoreCp:Int,
    val depth:Int,
    val nodes:Long,
    val creative:Float,
    val sacrifice:Float,
    val constraint:Float,
    val novelty:Float
)

class AnalysisController(context: Context) {
    private val runtime = ModelRuntime(context.applicationContext)
    private val running = AtomicBoolean(false)
    private val pool = Executors.newSingleThreadExecutor()

    fun loadModel(): Result<Unit> = runtime.load()
    fun isModelLoaded() = runtime.isLoaded()

    fun start(callback:(List<ModelRuntime.PriorLine>,Long,Throwable?)->Unit) {
        if (!running.compareAndSet(false,true)) return
        pool.execute {
            val start = SystemClock.elapsedRealtime()
            try {
                val result = runCatching { runtime.analyzeStartPosition() }
                callback(result.getOrDefault(emptyList()), SystemClock.elapsedRealtime()-start, result.exceptionOrNull())
            } finally { running.set(false) }
        }
    }

    fun stop() { running.set(false) }
    fun close() { pool.shutdownNow() }
}
