package com.brilliantmax.chess

class AnalysisController(private val context: android.content.Context) : AutoCloseable {
    private val prior=ModelRuntime(context); private val sf=StockfishProcess(context); private var engine:AnalysisEngine?=null
    fun load():Result<Unit>{ val r=prior.load();if(r.isSuccess)engine=AnalysisEngine(prior,sf);return r }
    fun loaded()=prior.isLoaded()
    fun legalMoves(fen:String):List<String> = sf.legalMoves(fen)
    fun analyze(fen:String,nodes:Long,candidates:Int,onDone:(AnalysisEngine.Result?,Throwable?)->Unit){Thread{try{onDone(engine!!.analyze(fen,nodes,candidates),null)}catch(t:Throwable){onDone(null,t)}}.start()}
    override fun close(){engine?.close()}
}
