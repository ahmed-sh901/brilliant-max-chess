package com.brilliantmax.chess

import android.content.Context

/** Creative search orchestration. Prior proposes; Stockfish verifies. */
class BmcSearch(context:Context) : AutoCloseable {
    data class Discovery(
        val move:String,
        val prior:Float,
        val creative:Float,
        val sacrifice:Float,
        val constraint:Float,
        val scoreCp:Int?,
        val mate:Int?,
        val depth:Int,
        val nodes:Long,
        val pv:List<String>,
        val legalResponsesBefore:Int,
        val legalResponsesAfter:Int,
        val responseReduction:Float,
        val brilliantEvidence:Float,
        val sound:Boolean,
        val sacrificeOffer:Boolean,
        val acceptedCapture:Boolean,
        val chainLength:Int
    )
    private val prior=PriorEngine(context)
    private val sf=StockfishProcess(context)
    fun load():Result<Unit>{ val a=prior.load(); if(a.isFailure)return a; return sf.start() }

    fun analyze(fen:String,budget:Long=2_000_000,candidateLimit:Int=8):List<Discovery>{
        val pos=ChessPosition.fromFen(fen)
        val legal=pos.legalMoves()
        require(legal.isNotEmpty()){"No legal moves"}
        val ranked=prior.rank(pos,legal).take(candidateLimit.coerceAtMost(legal.size))
        val perMove=(budget/maxOf(1,ranked.size)).coerceAtLeast(20_000)
        val before=legal.size
        return ranked.mapNotNull { pl ->
            val mv=legal.firstOrNull{it.uci()==pl.move} ?: return@mapNotNull null
            val after=pos.copy().apply{make(mv)}
            val responses=after.legalMoves().size
            val reduction=((before-responses).toFloat()/before.coerceAtLeast(1)).coerceIn(-1f,1f)
            val attacked=pieceAttackedAfter(pos,mv)
            val r=sf.verify(pos.fen(),mv.uci(),perMove)
            val sound = when {
                r.mate?.let { it > 0 } == true -> true
                r.mate?.let { it < 0 } == true -> false
                r.scoreCp?.let { it >= -80 } == true -> true
                else -> false
            }
            val pv=if(r.pv.firstOrNull()?.equals(mv.uci(), ignoreCase=true)==true) r.pv else listOf(mv.uci())+r.pv
            val accepted=attacked && pv.drop(1).take(4).any { it.length >= 4 && it.substring(2,4).equals(ChessMove.squareName(mv.to), ignoreCase=true) }
            val chainLength=countSacrificeOffers(pos,pv)
            val creative=(pl.creative*0.45f+pl.sacrifice*0.20f+pl.constraint*0.20f+reduction.coerceAtLeast(0f)*0.15f)
            Discovery(mv.uci(),pl.policyScore,creative,pl.sacrifice,pl.constraint,r.scoreCp,r.mate,r.depth,r.nodes,pv,before,responses,reduction,pl.brilliant,sound,attacked,accepted,chainLength)
        }.sortedWith(compareByDescending<Discovery>{it.sound}.thenByDescending{it.creative})
    }
    private fun countSacrificeOffers(start:ChessPosition,pv:List<String>):Int {
        var p=start.copy()
        var count=0
        for (uci in pv.take(12)) {
            val m=p.findLegalMove(uci) ?: break
            val moving=p.board[m.from]
            val after=p.copy().apply { make(m) }
            val pieceType=if (moving > 6) moving-6 else moving
            if (pieceType != ChessPosition.WP && after.legalMoves().any { it.to == m.to }) count++
            p=after
        }
        return count
    }

    private fun pieceAttackedAfter(before:ChessPosition,m:ChessMove):Boolean{
        val q=before.copy();q.make(m);val attackers=q.legalMoves() // legalMoves for opponent after side flip
        return attackers.any{it.to==m.to}
    }
    fun stop(){ sf.close() }
    override fun close(){sf.close()}
}
