package com.brilliantmax.chess

import android.content.Context
import kotlin.math.abs

/** Creative search orchestration. Prior proposes; Stockfish verifies. */
class BmcSearch(context:Context) : AutoCloseable {
    data class Discovery(
        val move:String,
        val prior:Float,
        val creative:Float,
        val sacrifice:Float,
        val constraint:Float,
        val scoreCp:Int?,
        val mate:Int?,
        val depth:Int,
        val nodes:Long,
        val pv:List<String>,
        val legalResponsesBefore:Int,
        val legalResponsesAfter:Int,
        val responseReduction:Float,
        val sound:Boolean,
        val sacrificeOffer:Boolean,
        val acceptedCapture:Boolean,
        val chainLength:Int
    )
    private val prior=PriorEngine(context)
    private val sf=StockfishProcess(context)
    fun load():Result<Unit>{ val a=prior.load(); if(a.isFailure)return a; return sf.start() }

    fun analyze(fen:String,budget:Long=2_000_000,candidateLimit:Int=8):List<Discovery>{
        val pos=ChessPosition.fromFen(fen)
        val legal=pos.legalMoves()
        require(legal.isNotEmpty()){"No legal moves"}
        val ranked=prior.rank(pos,legal).take(candidateLimit.coerceAtMost(legal.size))
        val perMove=(budget/maxOf(1,ranked.size)).coerceAtLeast(20_000)
        val before=legal.size
        return ranked.mapNotNull { pl ->
            val mv=legal.firstOrNull{it.uci()==pl.move} ?: return@mapNotNull null
            val after=pos.copy().apply{make(mv)}
            val responses=after.legalMoves().size
            val reduction=((before-responses).toFloat()/before.coerceAtLeast(1)).coerceIn(-1f,1f)
            val attacked=pieceAttackedAfter(pos,mv)
            val r=sf.verify(pos.fen(),mv.uci(),perMove)
            val sound=when{r.mate!=null&&r.mate!!>0->true;r.mate!=null&&r.mate!!<0->false;r.scoreCp!=null->r.scoreCp!!>=-80;else->false}
            val accepted=attacked && r.pv.drop(1).take(4).any{it.endsWith(ChessMove.squareName(mv.to))}
            val creative=(pl.probabilities[6]*0.45f+pl.probabilities[2]*0.20f+pl.probabilities[3]*0.20f+reduction.coerceAtLeast(0f)*0.15f)
            Discovery(mv.uci(),pl.policyScore,creative,pl.probabilities[2],pl.probabilities[3],r.scoreCp,r.mate,r.depth,r.nodes,r.pv,before,responses,reduction,sound,attacked,accepted,if(accepted)2 else 0)
        }.sortedWith(compareByDescending<Discovery>{it.sound}.thenByDescending{it.creative})
    }
    private fun pieceAttackedAfter(before:ChessPosition,m:ChessMove):Boolean{
        val q=before.copy();q.make(m);val moved=q.board[m.to];val attackers=q.legalMoves() // legalMoves for opponent after side flip
        return attackers.any{it.to==m.to}
    }
    fun stop(){ sf.close() }
    override fun close(){sf.close()}
}
