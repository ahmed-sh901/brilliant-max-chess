package com.brilliantmax.chess

/** Small, dependency-free orthodox chess rules layer used only for root move generation and UI state.
 * Stockfish remains the authoritative deep verifier/searcher.
 */
data class ChessMove(val from:Int, val to:Int, val promotion:Int = 0, val isEnPassant:Boolean = false, val isCastle:Boolean = false) {
    fun uci(): String {
        val s = squareName(from) + squareName(to)
        return if (promotion == 0) s else s + when (promotion) { 5 -> "q"; 4 -> "r"; 3 -> "b"; 2 -> "n"; else -> "q" }
    }
    companion object {
        fun squareName(sq:Int):String { val f = sq and 7; val r = 7 - (sq ushr 3); return "${('a'.code+f).toChar()}${r+1}" }
    }
}

class ChessPosition private constructor(
    val board:IntArray,
    var whiteToMove:Boolean,
    var castling:Int,
    var epSquare:Int,
    var halfmove:Int,
    var fullmove:Int
) {
    companion object {
        const val EMPTY=0
        const val WP=1; const val WN=2; const val WB=3; const val WR=4; const val WQ=5; const val WK=6
        const val BP=7; const val BN=8; const val BB=9; const val BR=10; const val BQ=11; const val BK=12
        const val WK_CASTLE=1; const val WQ_CASTLE=2; const val BK_CASTLE=4; const val BQ_CASTLE=8
        val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

        fun start() = fromFen(START_FEN)
        fun fromFen(fen:String):ChessPosition {
            val p=fen.trim().split(Regex("\\s+"))
            require(p.size>=4) { "Invalid FEN: $fen" }
            val b=IntArray(64)
            var sq=0
            for(ch in p[0]) {
                when {
                    ch=='/' -> Unit
                    ch.isDigit() -> sq += ch.digitToInt()
                    else -> { b[sq++]=charPiece(ch); }
                }
            }
            require(sq==64) { "Invalid FEN board" }
            var rights=0
            if(p[2].contains('K')) rights=rights or WK_CASTLE
            if(p[2].contains('Q')) rights=rights or WQ_CASTLE
            if(p[2].contains('k')) rights=rights or BK_CASTLE
            if(p[2].contains('q')) rights=rights or BQ_CASTLE
            require(p[1] == "w" || p[1] == "b") { "Invalid side to move" }
            require(p[2] == "-" || p[2].all { it in "KQkq" } && p[2].toSet().size == p[2].length) { "Invalid castling rights" }
            val ep=if(p[3]=="-") -1 else parseSquare(p[3]).also { require(it / 8 == if (p[1] == "w") 2 else 5) { "Invalid en-passant square" } }
            require(b.count { it == WK } == 1 && b.count { it == BK } == 1) { "FEN must contain exactly one king per side" }
            require((castlingRookRequirement(b, rights))) { "Castling rights do not match king/rook placement" }
            require(b.take(8).none { it == WP || it == BP } && b.takeLast(8).none { it == WP || it == BP }) { "Pawn on first/eighth rank" }
            val half=p.getOrNull(4)?.toIntOrNull() ?: 0
            val full=p.getOrNull(5)?.toIntOrNull() ?: 1
            require(half >= 0 && full >= 1) { "Invalid move counters" }
            return ChessPosition(b,p[1]=="w",rights,ep,half,full)
        }
        private fun castlingRookRequirement(b:IntArray, rights:Int):Boolean {
            if ((rights and WK_CASTLE) != 0 && (b[60] != WK || b[63] != WR)) return false
            if ((rights and WQ_CASTLE) != 0 && (b[60] != WK || b[56] != WR)) return false
            if ((rights and BK_CASTLE) != 0 && (b[4] != BK || b[7] != BR)) return false
            if ((rights and BQ_CASTLE) != 0 && (b[4] != BK || b[0] != BR)) return false
            return true
        }

        private fun charPiece(c:Char)=when(c){
            'P'->WP;'N'->WN;'B'->WB;'R'->WR;'Q'->WQ;'K'->WK;
            'p'->BP;'n'->BN;'b'->BB;'r'->BR;'q'->BQ;'k'->BK;else->0
        }
        fun parseSquare(s:String):Int { require(s.length==2); return (8-(s[1]-'0'))*8+(s[0]-'a') }
        fun squareName(sq:Int)=ChessMove.squareName(sq)
    }

    fun copy()=ChessPosition(board.copyOf(),whiteToMove,castling,epSquare,halfmove,fullmove)

    fun findLegalMove(uci:String):ChessMove? = legalMoves().firstOrNull { it.uci().equals(uci, ignoreCase=true) }

    fun fen():String {
        val sb=StringBuilder()
        for(r in 0 until 8){ var empty=0; for(f in 0 until 8){ val pc=board[r*8+f]; if(pc==0) empty++ else { if(empty>0){sb.append(empty);empty=0}; sb.append(pieceChar(pc)) } }; if(empty>0)sb.append(empty); if(r!=7)sb.append('/') }
        sb.append(' ').append(if(whiteToMove)'w' else 'b').append(' ')
        sb.append(if(castling==0)"-" else buildString { if((castling and WK_CASTLE)!=0)append('K');if((castling and WQ_CASTLE)!=0)append('Q');if((castling and BK_CASTLE)!=0)append('k');if((castling and BQ_CASTLE)!=0)append('q') })
        sb.append(' ').append(if(epSquare<0)"-" else squareName(epSquare)).append(' ').append(halfmove).append(' ').append(fullmove)
        return sb.toString()
    }
    private fun pieceChar(p:Int)=when(p){WP->'P';WN->'N';WB->'B';WR->'R';WQ->'Q';WK->'K';BP->'p';BN->'n';BB->'b';BR->'r';BQ->'q';BK->'k';else->'1'}
    private fun white(p:Int)=p in WP..WK
    private fun own(p:Int)=p!=0 && white(p)==whiteToMove
    private fun enemy(p:Int)=p!=0 && white(p)!=whiteToMove
    private fun enemyOf(p:Int, sideWhite:Boolean)=p!=0 && white(p)!=sideWhite
    private fun type(p:Int)=if(p>6)p-6 else p

    fun legalMoves():List<ChessMove> {
        val out=ArrayList<ChessMove>()
        for(sq in 0 until 64) if(own(board[sq])) generatePseudo(sq,out)
        return out.filter { m -> val q=copy(); q.make(m); !q.inCheck(!q.whiteToMove) }
    }

    fun make(m:ChessMove) {
        val pc=board[m.from]
        val target=board[m.to]
        board[m.from]=EMPTY
        if(m.isEnPassant) board[if(white(pc)) m.to+8 else m.to-8]=EMPTY
        board[m.to]=if(m.promotion==0) pc else if(white(pc)) m.promotion else m.promotion+6
        if(m.isCastle) {
            when(m.to) {
                62 -> { board[61]=WR;board[63]=EMPTY }
                58 -> { board[59]=WR;board[56]=EMPTY }
                6 -> { board[5]=BR;board[7]=EMPTY }
                2 -> { board[3]=BR;board[0]=EMPTY }
            }
        }
        when(m.from){60->castling=castling and (WK_CASTLE.inv() and WQ_CASTLE.inv());56->castling=castling and WQ_CASTLE.inv();63->castling=castling and WK_CASTLE.inv();4->castling=castling and (BK_CASTLE.inv() and BQ_CASTLE.inv());0->castling=castling and BQ_CASTLE.inv();7->castling=castling and BK_CASTLE.inv()}
        when(m.to){60->castling=castling and (WK_CASTLE.inv() and WQ_CASTLE.inv());56->castling=castling and WQ_CASTLE.inv();63->castling=castling and WK_CASTLE.inv();4->castling=castling and (BK_CASTLE.inv() and BQ_CASTLE.inv());0->castling=castling and BQ_CASTLE.inv();7->castling=castling and BK_CASTLE.inv()}
        epSquare = if(type(pc)==1 && kotlin.math.abs(m.to-m.from)==16) (m.to+m.from)/2 else -1
        halfmove = if(type(pc)==1 || target!=0 || m.isEnPassant) 0 else halfmove+1
        if(!whiteToMove)fullmove++
        whiteToMove=!whiteToMove
    }

    private fun add(out:MutableList<ChessMove>,from:Int,to:Int,promo:Boolean=false,enPassant:Boolean=false,castle:Boolean=false){
        if(to !in 0..63)return
        val t=board[to]
        if(t!=0 && white(t)==whiteToMove)return
        if(type(t)==6)return // kings cannot be captured as a legal move
        if(promo && ((whiteToMove && to/8==0)||(!whiteToMove && to/8==7))) for(x in intArrayOf(5,4,3,2)) out.add(ChessMove(from,to,x,enPassant,castle))
        else out.add(ChessMove(from,to,0,enPassant,castle))
    }
    private fun generatePseudo(sq:Int,out:MutableList<ChessMove>) {
        val pc=board[sq]; val t=type(pc); val r=sq/8; val f=sq and 7
        when(t){
            1 -> { val d=if(whiteToMove)-1 else 1; val one=(r+d)*8+f; if(one in 0..63&&board[one]==0){add(out,sq,one,true); val start=if(whiteToMove)6 else 1; val two=(r+2*d)*8+f;if(r==start&&board[two]==0)add(out,sq,two)}; for(df in intArrayOf(-1,1)){val nf=f+df;val nr=r+d;if(nf in 0..7&&nr in 0..7){val to=nr*8+nf;if(enemy(board[to]))add(out,sq,to,true);if(to==epSquare)add(out,sq,to,false,true)}} }
            2 -> for(df in intArrayOf(-2,-1,1,2))for(dr in intArrayOf(-2,-1,1,2))if(kotlin.math.abs(df)+kotlin.math.abs(dr)==3){val nf=f+df;val nr=r+dr;if(nf in 0..7&&nr in 0..7)add(out,sq,nr*8+nf)}
            3,4,5 -> { val dirs=when(t){3->intArrayOf(-9,-7,7,9);4->intArrayOf(-8,8,-1,1);else->intArrayOf(-9,-8,-7,-1,1,7,8,9)}; for(d in dirs){var cur=sq;while(true){val nr=cur/8+when(d){-9,-8,-7->-1;7,8,9->1;else->0};val nf=cur%8+when(d){-9,-1,7->-1;-7,1,9->1;else->0};if(nr !in 0..7||nf !in 0..7)break;cur=nr*8+nf;if(board[cur]==0)out.add(ChessMove(sq,cur)) else {if(enemy(board[cur]))add(out,sq,cur);break}} } }
            6 -> { for(dr in -1..1)for(df in -1..1)if(dr!=0||df!=0){val nr=r+dr;val nf=f+df;if(nr in 0..7&&nf in 0..7)add(out,sq,nr*8+nf)}; if(whiteToMove&&sq==60&&!inCheck(true)){if((castling and WK_CASTLE)!=0&&board[61]==0&&board[62]==0&&!isAttacked(61,false)&&!isAttacked(62,false))out.add(ChessMove(60,62,0,false,true));if((castling and WQ_CASTLE)!=0&&board[59]==0&&board[58]==0&&board[57]==0&&!isAttacked(59,false)&&!isAttacked(58,false))out.add(ChessMove(60,58,0,false,true))};if(!whiteToMove&&sq==4&&!inCheck(false)){if((castling and BK_CASTLE)!=0&&board[5]==0&&board[6]==0&&!isAttacked(5,true)&&!isAttacked(6,true))out.add(ChessMove(4,6,0,false,true));if((castling and BQ_CASTLE)!=0&&board[3]==0&&board[2]==0&&board[1]==0&&!isAttacked(3,true)&&!isAttacked(2,true))out.add(ChessMove(4,2,0,false,true))} }
        }
    }

    fun inCheck(sideWhite:Boolean):Boolean { val king=if(sideWhite)WK else BK; val sq=board.indexOf(king); return sq>=0 && isAttacked(sq,!sideWhite) }
    private fun isAttacked(sq:Int,byWhite:Boolean):Boolean {
        val r=sq/8;val f=sq and 7
        val pawn=if(byWhite)WP else BP; val pr=r+if(byWhite)1 else -1
        if(pr in 0..7)for(df in intArrayOf(-1,1)){val nf=f+df;if(nf in 0..7&&board[pr*8+nf]==pawn)return true}
        val knight=if(byWhite)WN else BN;for(df in intArrayOf(-2,-1,1,2))for(dr in intArrayOf(-2,-1,1,2))if(kotlin.math.abs(df)+kotlin.math.abs(dr)==3){val nf=f+df;val nr=r+dr;if(nf in 0..7&&nr in 0..7&&board[nr*8+nf]==knight)return true}
        val bishop=if(byWhite)WB else BB;val rook=if(byWhite)WR else BR;val queen=if(byWhite)WQ else BQ;val king=if(byWhite)WK else BK
        for(df in -1..1)for(dr in -1..1)if(df!=0||dr!=0){var nf=f+df;var nr=r+dr;var first=true;while(nf in 0..7&&nr in 0..7){val p=board[nr*8+nf];if(p!=0){if(first&&p==king)return true;if((df==0||dr==0)&&p==rook||p==queen)return true;if((df!=0&&dr!=0)&&p==bishop||p==queen)return true;break};first=false;nf+=df;nr+=dr}}
        return false
    }
}
