package com.brilliantmax.chess

/** Immutable chess position. Board indexing is a8=0 ... h1=63. */
data class ChessMove(
    val from: Int,
    val to: Int,
    val promotion: Int = 0,
    val isEnPassant: Boolean = false,
    val isCastle: Boolean = false
) {
    fun uci(): String {
        val p = if (promotion == 0) "" else when (promotion) {
            5 -> "q"; 4 -> "r"; 3 -> "b"; 2 -> "n"; else -> ""
        }
        return squareName(from) + squareName(to) + p
    }
}

private fun squareName(sq: Int): String {
    val file = sq and 7
    val rank = 8 - (sq ushr 3)
    return "${('a'.code + file).toChar()}$rank"
}

object Piece {
    const val EMPTY = 0
    const val WP = 1; const val WN = 2; const val WB = 3; const val WR = 4; const val WQ = 5; const val WK = 6
    const val BP = 7; const val BN = 8; const val BB = 9; const val BR = 10; const val BQ = 11; const val BK = 12
    fun color(p: Int): Int = if (p >= BP) 1 else 0
    fun type(p: Int): Int = when {
        p == 0 -> 0
        p >= BP -> p - 6
        else -> p
    }
    fun isPawn(p: Int) = type(p) == 1
    fun isKing(p: Int) = type(p) == 6
}

data class ChessPosition(
    val board: IntArray,
    val whiteToMove: Boolean,
    val castling: Int,
    val epSquare: Int,
    val halfmove: Int = 0,
    val fullmove: Int = 1
) {
    companion object {
        const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

        fun start() = fromFen(START_FEN)

        fun fromFen(fen: String): ChessPosition {
            val f = fen.trim().split(Regex("\\s+"))
            require(f.size >= 4) { "Invalid FEN" }
            val b = IntArray(64)
            var sq = 0
            for (ch in f[0]) {
                when {
                    ch == '/' -> Unit
                    ch.isDigit() -> sq += ch.digitToInt()
                    else -> { b[sq++] = fenPiece(ch) }
                }
            }
            require(sq == 64) { "Invalid FEN board" }
            var rights = 0
            for (c in f[2]) rights = rights or when (c) { 'K' -> 1; 'Q' -> 2; 'k' -> 4; 'q' -> 8; else -> 0 }
            val ep = if (f[3] == "-") -1 else parseSquare(f[3])
            return ChessPosition(b, f[1] == "w", rights, ep,
                f.getOrNull(4)?.toIntOrNull() ?: 0,
                f.getOrNull(5)?.toIntOrNull() ?: 1)
        }

        private fun fenPiece(c: Char) = when (c) {
            'P' -> Piece.WP; 'N' -> Piece.WN; 'B' -> Piece.WB; 'R' -> Piece.WR; 'Q' -> Piece.WQ; 'K' -> Piece.WK
            'p' -> Piece.BP; 'n' -> Piece.BN; 'b' -> Piece.BB; 'r' -> Piece.BR; 'q' -> Piece.BQ; 'k' -> Piece.BK
            else -> error("Invalid FEN piece")
        }

        fun parseSquare(s: String): Int {
            require(s.length == 2 && s[0] in 'a'..'h' && s[1] in '1'..'8')
            return (8 - (s[1] - '0')) * 8 + (s[0] - 'a')
        }
    }

    fun fen(): String {
        val sb = StringBuilder()
        for (r in 0 until 8) {
            var empty = 0
            for (f in 0 until 8) {
                val p = board[r * 8 + f]
                if (p == 0) empty++ else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(pieceFen(p))
                }
            }
            if (empty > 0) sb.append(empty)
            if (r != 7) sb.append('/')
        }
        sb.append(if (whiteToMove) " w " else " b ")
        sb.append(buildString {
            if ((castling and 1) != 0) append('K')
            if ((castling and 2) != 0) append('Q')
            if ((castling and 4) != 0) append('k')
            if ((castling and 8) != 0) append('q')
        }.ifEmpty { "-" })
        sb.append(' ')
        sb.append(if (epSquare < 0) "-" else squareName(epSquare))
        sb.append(" $halfmove $fullmove")
        return sb.toString()
    }

    fun legalMoves(): List<ChessMove> = LegalMoveGenerator.generate(this)

    fun apply(move: ChessMove): ChessPosition {
        val b = board.copyOf()
        val moving = b[move.from]
        val captured = if (move.isEnPassant) b[move.to + if (whiteToMove) 8 else -8] else b[move.to]
        b[move.from] = 0
        if (move.isEnPassant) b[move.to + if (whiteToMove) 8 else -8] = 0
        b[move.to] = if (move.promotion != 0) {
            if (whiteToMove) move.promotion else move.promotion + 6
        } else moving

        if (move.isCastle) {
            when (move.to) {
                62 -> { b[61] = Piece.WR; b[63] = 0 }
                58 -> { b[59] = Piece.WR; b[56] = 0 }
                6 -> { b[5] = Piece.BR; b[7] = 0 }
                2 -> { b[3] = Piece.BR; b[0] = 0 }
            }
        }

        var rights = castling
        when (move.from) {
            60 -> rights = rights and 3.inv()
            63 -> rights = rights and 1.inv()
            56 -> rights = rights and 2.inv()
            4 -> rights = rights and 12.inv()
            7 -> rights = rights and 4.inv()
            0 -> rights = rights and 8.inv()
        }
        when (move.to) {
            63 -> rights = rights and 1.inv()
            56 -> rights = rights and 2.inv()
            7 -> rights = rights and 4.inv()
            0 -> rights = rights and 8.inv()
        }

        val newEp = if (Piece.isPawn(moving) && kotlin.math.abs(move.to - move.from) == 16)
            (move.from + move.to) / 2 else -1
        return ChessPosition(b, !whiteToMove, rights, newEp,
            if (Piece.isPawn(moving) || captured != 0) 0 else halfmove + 1,
            if (!whiteToMove) fullmove + 1 else fullmove)
    }

    private fun pieceFen(p: Int) = when (p) {
        Piece.WP -> 'P'; Piece.WN -> 'N'; Piece.WB -> 'B'; Piece.WR -> 'R'; Piece.WQ -> 'Q'; Piece.WK -> 'K'
        Piece.BP -> 'p'; Piece.BN -> 'n'; Piece.BB -> 'b'; Piece.BR -> 'r'; Piece.BQ -> 'q'; Piece.BK -> 'k'
        else -> error("bad piece")
    }
}

object LegalMoveGenerator {
    private val knight = intArrayOf(-17,-15,-10,-6,6,10,15,17)
    private val king = intArrayOf(-9,-8,-7,-1,1,7,8,9)
    private val bishopDirs = intArrayOf(-9,-7,7,9)
    private val rookDirs = intArrayOf(-8,-1,1,8)

    fun generate(pos: ChessPosition): List<ChessMove> {
        val pseudo = ArrayList<ChessMove>(64)
        for (sq in 0 until 64) {
            val p = pos.board[sq]
            if (p == 0 || Piece.color(p) != if (pos.whiteToMove) 0 else 1) continue
            when (Piece.type(p)) {
                1 -> pawn(pos, sq, pseudo)
                2 -> knight(pos, sq, pseudo)
                3 -> slide(pos, sq, bishopDirs, pseudo)
                4 -> slide(pos, sq, rookDirs, pseudo)
                5 -> { slide(pos, sq, bishopDirs, pseudo); slide(pos, sq, rookDirs, pseudo) }
                6 -> king(pos, sq, pseudo)
            }
        }
        return pseudo.filter { move ->
            val next = pos.apply(move)
            !isInCheck(next, pos.whiteToMove)
        }
    }

    fun isSquareAttacked(pos: ChessPosition, target: Int, byWhite: Boolean): Boolean {
        val b = pos.board
        val tr = target / 8; val tf = target and 7
        val pawn = if (byWhite) Piece.WP else Piece.BP
        val pawnRow = if (byWhite) tr + 1 else tr - 1
        if (pawnRow in 0..7) for (df in intArrayOf(-1,1)) {
            val f = tf + df
            if (f in 0..7 && b[pawnRow*8+f] == pawn) return true
        }
        val n = if (byWhite) Piece.WN else Piece.BN
        for (d in knight) {
            val s = target + d
            if (s !in 0..63) continue
            val dr = kotlin.math.abs(s/8-tr); val df=kotlin.math.abs((s and 7)-tf)
            if (dr <= 2 && df <= 2 && b[s] == n) return true
        }
        if (rayAttacked(b, target, byWhite, bishopDirs, Piece.type(if (byWhite) Piece.WB else Piece.BB), Piece.type(if (byWhite) Piece.WQ else Piece.BQ))) return true
        if (rayAttacked(b, target, byWhite, rookDirs, Piece.type(if (byWhite) Piece.WR else Piece.BR), Piece.type(if (byWhite) Piece.WQ else Piece.BQ))) return true
        val k = if (byWhite) Piece.WK else Piece.BK
        for (d in king) {
            val s=target+d; if(s !in 0..63) continue
            if(kotlin.math.abs(s/8-tr)<=1 && kotlin.math.abs((s and 7)-tf)<=1 && b[s]==k) return true
        }
        return false
    }

    private fun rayAttacked(b:IntArray,target:Int,byWhite:Boolean,dirs:IntArray,sliderType:Int,queenType:Int):Boolean {
        val tr=target/8; val tf=target and 7
        for(d in dirs){
            var s=target
            while(true){
                val next=s+d; if(next !in 0..63) break
                if(kotlin.math.abs((next and 7)-(s and 7))>1) break
                s=next
                val p=b[s]
                if(p==0) continue
                if(Piece.color(p)==(if(byWhite) 0 else 1) && (Piece.type(p)==sliderType || Piece.type(p)==queenType)) return true
                break
            }
        }
        return false
    }

    private fun pawn(pos:ChessPosition,sq:Int,out:MutableList<ChessMove>){
        val b=pos.board; val white=pos.whiteToMove; val dir=if(white)-8 else 8; val start=if(white)48 else 8; val promoRank=if(white)0 else 56
        val one=sq+dir
        if(one in 0..63 && b[one]==0){ addPawnMove(sq,one,promoRank,out); if(sq in start until start+8){ val two=sq+2*dir; if(b[two]==0) out.add(ChessMove(sq,two)) } }
        val row=sq/8; val file=sq and 7
        for(df in intArrayOf(-1,1)){ val to=sq+dir+df; if(to !in 0..63 || kotlin.math.abs((to and 7)-file)!=1) continue; val target=b[to]; if(target!=0 && Piece.color(target)!=if(white)0 else 1) addPawnMove(sq,to,promoRank,out); if(to==pos.epSquare) out.add(ChessMove(sq,to,0,true,false)) }
    }
    private fun addPawnMove(from:Int,to:Int,promoRank:Int,out:MutableList<ChessMove>){ if(to/8==promoRank/8) for(p in 5 downTo 2) out.add(ChessMove(from,to,p)) else out.add(ChessMove(from,to)) }
    private fun knight(pos:ChessPosition,sq:Int,out:MutableList<ChessMove>){ val b=pos.board; val own=if(pos.whiteToMove)0 else 1; val r=sq/8; val f=sq and 7; for(d in knight){val t=sq+d;if(t !in 0..63)continue;if(kotlin.math.abs(t/8-r)>2||kotlin.math.abs((t and 7)-f)>2)continue;if(b[t]==0||Piece.color(b[t])!=own)out.add(ChessMove(sq,t))} }
    private fun slide(pos:ChessPosition,sq:Int,dirs:IntArray,out:MutableList<ChessMove>){ val b=pos.board; val own=if(pos.whiteToMove)0 else 1; for(d in dirs){var s=sq;while(true){val t=s+d;if(t !in 0..63)break;if(kotlin.math.abs((t and 7)-(s and 7))>1)break;s=t;val p=b[s];if(p==0)out.add(ChessMove(sq,s))else{if(Piece.color(p)!=own)out.add(ChessMove(sq,s));break}}} }
    private fun king(pos:ChessPosition,sq:Int,out:MutableList<ChessMove>){ val b=pos.board;val own=if(pos.whiteToMove)0 else 1;val r=sq/8;val f=sq and 7;for(d in king){val t=sq+d;if(t !in 0..63)continue;if(kotlin.math.abs(t/8-r)>1||kotlin.math.abs((t and 7)-f)>1)continue;if(b[t]==0||Piece.color(b[t])!=own)out.add(ChessMove(sq,t))}
        if(pos.whiteToMove && sq==60 && !isInCheck(pos,true)){
            if((pos.castling and 1)!=0 && b[61]==0&&b[62]==0&&!isSquareAttacked(pos,61,false)&&!isSquareAttacked(pos,62,false))out.add(ChessMove(60,62,0,false,true))
            if((pos.castling and 2)!=0 && b[59]==0&&b[58]==0&&b[57]==0&&!isSquareAttacked(pos,59,false)&&!isSquareAttacked(pos,58,false))out.add(ChessMove(60,58,0,false,true))
        } else if(!pos.whiteToMove && sq==4 && !isInCheck(pos,false)){
            if((pos.castling and 4)!=0 && b[5]==0&&b[6]==0&&!isSquareAttacked(pos,5,true)&&!isSquareAttacked(pos,6,true))out.add(ChessMove(4,6,0,false,true))
            if((pos.castling and 8)!=0 && b[3]==0&&b[2]==0&&b[1]==0&&!isSquareAttacked(pos,3,true)&&!isSquareAttacked(pos,2,true))out.add(ChessMove(4,2,0,false,true))
        }
    }
    fun isInCheck(pos:ChessPosition,white:Boolean):Boolean{val k=if(white)Piece.WK else Piece.BK;val sq=pos.board.indexOf(k);return sq<0||isSquareAttacked(pos,sq,!white)}
}
