package com.brilliantmax.chess

import android.content.Context
import org.pytorch.IValue
import org.pytorch.LiteModuleLoader
import org.pytorch.Module
import org.pytorch.Tensor
import java.io.File
import java.io.FileOutputStream

/** Frozen v1.52 Prior adapter. The model is a policy/ranking guide, never the soundness authority. */
class ModelRuntime(private val context: Context) {
    companion object { private const val ASSET = "mobile_prior_v52_7head_mix2250.ptl" }
    private var module: Module? = null
    @Synchronized fun load(): Result<Unit> = runCatching { if (module == null) module = LiteModuleLoader.load(assetFilePath(ASSET)) }
    fun isLoaded() = module != null

    fun rank(fen: String, moves: List<String>): List<PriorLine> {
        require(moves.isNotEmpty()) { "No legal moves" }
        val m = module ?: error("Prior runtime is not loaded")
        val b = FenBoard.fromFen(fen)
        val pieces = LongArray(64) { pieceCode(b.squares[it]) }
        val side = longArrayOf(if (b.whiteToMove) 0 else 1)
        val rights = longArrayOf(castlingCode(b.castling))
        val ep = longArrayOf(b.ep.toLong())
        val flat = LongArray(moves.size * 3)
        moves.forEachIndexed { i, move -> val c = uciToCandidate(move); flat[i*3]=c[0].toLong(); flat[i*3+1]=c[1].toLong(); flat[i*3+2]=c[2].toLong() }
        val output = m.forward(IValue.from(Tensor.fromBlob(pieces,longArrayOf(1,64))), IValue.from(Tensor.fromBlob(side,longArrayOf(1))), IValue.from(Tensor.fromBlob(rights,longArrayOf(1))), IValue.from(Tensor.fromBlob(ep,longArrayOf(1))), IValue.from(Tensor.fromBlob(flat,longArrayOf(1,moves.size.toLong(),3))))
        val out = output.toTensor().dataAsFloatArray
        return moves.mapIndexed { i, move ->
            val p = FloatArray(7) { sigmoid(out[i*7+it]) }
            val score = p[0]*.08f+p[1]*.16f+p[2]*.16f+p[3]*.18f+p[4]*.05f+p[5]*.17f+p[6]*.20f
            PriorLine(move,score,p)
        }.sortedByDescending { it.policyScore }
    }

    private fun pieceCode(c: Char): Long = when(c){ 'P'->1;'N'->2;'B'->3;'R'->4;'Q'->5;'K'->6;'p'->7;'n'->8;'b'->9;'r'->10;'q'->11;'k'->12;else->0 }.toLong()
    private fun castlingCode(c:String):Long=(if('K'in c)1 else 0)+(if('Q'in c)2 else 0)+(if('k'in c)4 else 0)+(if('q'in c)8 else 0)
    private fun sigmoid(x:Float)=1f/(1f+kotlin.math.exp(-x.coerceIn(-40f,40f)))
    private fun square(s:String)=FenBoard.square(s)
    private fun uciToCandidate(move:String):IntArray { val promo=if(move.length==5)when(move[4]){'q'->1;'r'->2;'b'->3;'n'->4;else->0}else 0;return intArrayOf(square(move.substring(0,2)),square(move.substring(2,4)),promo) }
    private fun assetFilePath(name:String):String { val f=File(context.filesDir,name);if(f.exists()&&f.length()>0)return f.absolutePath;context.assets.open(name).use{input->FileOutputStream(f).use{input.copyTo(it)}};return f.absolutePath }
    data class PriorLine(val move:String,val policyScore:Float,val probabilities:FloatArray)
}
