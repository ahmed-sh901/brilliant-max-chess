package com.brilliantmax.chess

import android.content.Context
import org.pytorch.IValue
import org.pytorch.LiteModuleLoader
import org.pytorch.Module
import org.pytorch.Tensor
import java.io.File
import java.io.FileOutputStream

/** Runs the frozen v1.52 seven-head Prior directly on Android.
 *
 * Contract:
 * pieces      [1,64] int64, a8..h1, empty=0, pieces=1..12
 * side        [1]    int64, white=0 black=1
 * castling    [1]    int64, K=1 Q=2 k=4 q=8
 * ep          [1]    int64, -1 or 0..63 in a8..h1 indexing
 * candidates  [1,C,3] int64, [from,to,promotion], promotion 0/1/2/3/4 = none/q/r/b/n (mapped from ChessMove 0/5/4/3/2)
 * output      [1,C,7] float32 logits
 */
class ModelRuntime(private val context: Context) {
    companion object {
        private const val ASSET = "mobile_prior_v52_7head_mix2250.ptl"

        // Legal moves from the standard starting position. This is deliberately
        // a smoke-test candidate set; the full legal-move/search layer comes next.
        private val START_MOVES = listOf(
            "a2a3","a2a4","b2b3","b2b4","c2c3","c2c4","d2d3","d2d4",
            "e2e3","e2e4","f2f3","f2f4","g2g3","g2g4","h2h3","h2h4",
            "b1a3","b1c3","g1f3","g1h3"
        )
        private val START_PIECES = longArrayOf(
            10,8,9,11,12,9,8,10,
            7,7,7,7,7,7,7,7,
            0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,
            1,1,1,1,1,1,1,1,
            4,2,3,5,6,3,2,4
        )
    }

    private var module: Module? = null

    @Synchronized
    fun load(): Result<Unit> {
        if (module != null) return Result.success(Unit)
        return runCatching {
            val path = assetFilePath(ASSET)
            module = LiteModuleLoader.load(path)
        }
    }

    fun isLoaded(): Boolean = module != null

    fun analyze(position: ChessPosition, moves: List<ChessMove>): List<PriorLine> {
        require(moves.isNotEmpty()) { "No legal candidates" }
        val m = module ?: error("Model runtime is not loaded")
        val pieces = LongArray(64)
        for (i in 0 until 64) pieces[i] = position.board[i].toLong()
        val piecesT = Tensor.fromBlob(pieces, longArrayOf(1,64))
        val sideT = Tensor.fromBlob(longArrayOf(if(position.whiteToMove) 0 else 1), longArrayOf(1))
        val castlingT = Tensor.fromBlob(longArrayOf(position.castling.toLong()), longArrayOf(1))
        val epT = Tensor.fromBlob(longArrayOf(position.epSquare.toLong()), longArrayOf(1))
        val flat = LongArray(moves.size * 3)
        moves.forEachIndexed { i, mv ->
            flat[i*3] = mv.from.toLong(); flat[i*3+1] = mv.to.toLong(); flat[i*3+2] = when (mv.promotion) { 5 -> 1; 4 -> 2; 3 -> 3; 2 -> 4; else -> 0 }.toLong()
        }
        val candidatesT = Tensor.fromBlob(flat, longArrayOf(1,moves.size.toLong(),3))
        val out = m.forward(IValue.from(piecesT),IValue.from(sideT),IValue.from(castlingT),IValue.from(epT),IValue.from(candidatesT)).toTensor().dataAsFloatArray
        return moves.mapIndexed { i, mv ->
            val base=i*7
            val p=FloatArray(7){sigmoid(out[base+it])}
            val score=p[0]*0.08f+p[1]*0.16f+p[2]*0.16f+p[3]*0.18f+p[4]*0.05f+p[5]*0.17f+p[6]*0.20f
            PriorLine(mv.uci(),score,p)
        }.sortedByDescending { it.policyScore }
    }

    fun analyzeStartPosition(): List<PriorLine> = analyze(ChessPosition.start(), ChessPosition.start().legalMoves())

    private fun sigmoid(x: Float): Float {
        val z = x.coerceIn(-40f, 40f)
        return (1f / (1f + kotlin.math.exp(-z)))
    }

    private fun assetFilePath(name: String): String {
        val file = File(context.filesDir, name)
        if (file.exists() && file.length() > 0L) return file.absolutePath
        context.assets.open(name).use { input ->
            FileOutputStream(file).use { output ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    output.write(buffer, 0, n)
                }
                output.flush()
            }
        }
        return file.absolutePath
    }

    private fun squareIndex(s: String): Int {
        val file = s[0] - 'a'
        val rank = s[1] - '0'
        return (8 - rank) * 8 + file
    }

    private fun uciToCandidate(move: String): IntArray {
        val promo = if (move.length == 5) when (move[4].lowercaseChar()) {
            'q' -> 1
            'r' -> 2
            'b' -> 3
            'n' -> 4
            else -> 0
        } else 0
        return intArrayOf(squareIndex(move.substring(0, 2)), squareIndex(move.substring(2, 4)), promo)
    }

    data class PriorLine(val move: String, val policyScore: Float, val probabilities: FloatArray)

}
