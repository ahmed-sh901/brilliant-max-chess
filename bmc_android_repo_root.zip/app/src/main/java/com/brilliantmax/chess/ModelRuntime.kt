package com.brilliantmax.chess

import android.content.Context
import org.pytorch.IValue
import org.pytorch.LiteModuleLoader
import org.pytorch.Module
import org.pytorch.Tensor
import java.io.File
import java.io.FileOutputStream
import kotlin.math.exp

/** Frozen v1.52 Move-Aware 7-head Prior runtime. */
class ModelRuntime(private val context: Context) {
    companion object { private const val ASSET = "mobile_prior_v52_7head_mix2250.ptl" }
    private var module: Module? = null

    @Synchronized fun load(): Result<Unit> = runCatching {
        if (module == null) module = LiteModuleLoader.load(assetFilePath(ASSET))
    }
    fun isLoaded() = module != null

    fun analyze(position: ChessPosition, limit: Int = 256): List<PriorLine> {
        val m = module ?: error("Model runtime is not loaded")
        val allMoves = position.legalMoves()
        val moves = if (limit >= allMoves.size) allMoves else allMoves.take(limit.coerceAtLeast(1))
        require(moves.isNotEmpty()) { "No legal moves" }
        val pieces = Tensor.fromBlob(position.board.map { it.toLong() }.toLongArray(), longArrayOf(1,64))
        val side = Tensor.fromBlob(longArrayOf(if (position.whiteToMove) 0 else 1), longArrayOf(1))
        val castling = Tensor.fromBlob(longArrayOf(position.castling.toLong()), longArrayOf(1))
        val ep = Tensor.fromBlob(longArrayOf(position.epSquare.toLong()), longArrayOf(1))
        val flat = LongArray(moves.size * 3)
        moves.forEachIndexed { i, move ->
            flat[i*3] = move.from.toLong(); flat[i*3+1] = move.to.toLong(); flat[i*3+2] = modelPromotion(move.promotion).toLong()
        }
        val candidates = Tensor.fromBlob(flat, longArrayOf(1,moves.size.toLong(),3))
        val output = m.forward(IValue.from(pieces), IValue.from(side), IValue.from(castling), IValue.from(ep), IValue.from(candidates))
        val out = output.toTensor().dataAsFloatArray
        return moves.mapIndexed { i, move ->
            val base=i*7; val p=FloatArray(7){sigmoid(out[base+it])}
            val score=p[0]*.08f+p[1]*.16f+p[2]*.16f+p[3]*.18f+p[4]*.05f+p[5]*.17f+p[6]*.20f
            PriorLine(move.uci(), score, p)
        }.sortedByDescending { it.policyScore }
    }

    private fun modelPromotion(p: Int) = when(p){5->1;4->2;3->3;2->4;else->0}
    private fun sigmoid(x:Float):Float{val z=x.coerceIn(-40f,40f);return 1f/(1f+exp(-z))}
    private fun assetFilePath(name:String):String{
        val file=File(context.filesDir,name);if(file.exists()&&file.length()>0)return file.absolutePath
        context.assets.open(name).use{input->FileOutputStream(file).use{output->input.copyTo(output)}}
        return file.absolutePath
    }
    data class PriorLine(val move:String,val policyScore:Float,val probabilities:FloatArray)
}
