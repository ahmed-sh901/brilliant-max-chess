#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <algorithm>
#include <filesystem>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>

#include "engine.h"
#include "score.h"
#include "search.h"
#include "uci.h"

using namespace Stockfish;

namespace {
std::mutex g_mutex;
std::unique_ptr<Engine> g_engine;
std::atomic<bool> g_stop{false};

void set_option(const std::string& name, const std::string& value) {
    std::istringstream ss("setoption name " + name + " value " + value);
    g_engine->get_options().setoption(ss);
}

int score_cp(const Score& score) {
    return score.visit(overload{
        [](Score::Mate m) -> int {
            if (m.plies > 0) return 20000 - m.plies;
            return -20000 - m.plies;
        },
        [](Score::Tablebase t) -> int {
            return (t.win ? 20000 : -20000) - t.plies;
        },
        [](Score::InternalUnits u) -> int { return u.value; }
    });
}

struct SearchResult {
    int cp = 0;
    int depth = 0;
    uint64_t nodes = 0;
    std::string bestmove;
    std::string pv;
};

SearchResult search(const std::string& fen,
                    const std::vector<std::string>& searchmoves,
                    uint64_t nodes) {
    SearchResult result;
    g_engine->set_position(fen, {});
    g_stop.store(false);

    g_engine->set_on_update_full([&result](const Engine::InfoFull& info) {
        result.cp = score_cp(info.score);
        result.depth = info.depth;
        result.nodes = info.nodes;
        result.pv = std::string(info.pv);
    });
    g_engine->set_on_bestmove([&result](std::string_view best, std::string_view) {
        result.bestmove = std::string(best);
    });

    Search::LimitsType limits;
    limits.nodes = nodes;
    limits.searchmoves = searchmoves;
    g_engine->go(limits);
    g_engine->wait_for_search_finished();
    return result;
}
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_brilliantmax_chess_NativeStockfish_nativeInit(
    JNIEnv* env, jobject, jstring networkDirJ) {
    std::lock_guard<std::mutex> lock(g_mutex);
    try {
        const char* chars = env->GetStringUTFChars(networkDirJ, nullptr);
        std::filesystem::path dir(chars ? chars : "");
        env->ReleaseStringUTFChars(networkDirJ, chars);

        g_engine.reset(new Engine(dir));
        set_option("NumaPolicy", "none");
        set_option("Threads", "1");
        set_option("Hash", "32");
        set_option("MultiPV", "1");
        return JNI_TRUE;
    } catch (const std::exception& e) {
        __android_log_print(ANDROID_LOG_ERROR, "BMC", "Stockfish init failed: %s", e.what());
        g_engine.reset();
        return JNI_FALSE;
    } catch (...) {
        __android_log_print(ANDROID_LOG_ERROR, "BMC", "Stockfish init failed: unknown exception");
        g_engine.reset();
        return JNI_FALSE;
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_brilliantmax_chess_NativeStockfish_nativeVerify(
    JNIEnv* env, jobject, jstring fenJ, jobjectArray candidatesJ, jlong totalNodesJ) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_engine) return env->NewStringUTF("ERROR\tStockfish not initialized");

    try {
        const char* fenChars = env->GetStringUTFChars(fenJ, nullptr);
        const std::string fen = fenChars ? fenChars : "";
        env->ReleaseStringUTFChars(fenJ, fenChars);

        std::vector<std::string> candidates;
        const jsize n = env->GetArrayLength(candidatesJ);
        candidates.reserve(static_cast<size_t>(n));
        for (jsize i = 0; i < n; ++i) {
            auto s = static_cast<jstring>(env->GetObjectArrayElement(candidatesJ, i));
            const char* c = env->GetStringUTFChars(s, nullptr);
            candidates.emplace_back(c ? c : "");
            env->ReleaseStringUTFChars(s, c);
            env->DeleteLocalRef(s);
        }

        if (candidates.empty()) return env->NewStringUTF("ERROR\tNo candidates");

        const uint64_t totalNodes = static_cast<uint64_t>(totalNodesJ > 1000 ? totalNodesJ : 1000);
        const uint64_t baselineBudget = std::max<uint64_t>(1000, totalNodes / 5);
        const uint64_t candidateBudget = std::max<uint64_t>(1000, (totalNodes - baselineBudget) / candidates.size());

        auto baseline = search(fen, {}, baselineBudget);

        std::ostringstream out;
        out << "BASE\t" << baseline.cp << '\t' << baseline.nodes << '\t' << baseline.depth
            << '\t' << baseline.bestmove << '\t' << baseline.pv << '\n';

        for (const auto& candidate : candidates) {
            auto r = search(fen, {candidate}, candidateBudget);
            const int loss = baseline.cp - r.cp;
            out << candidate << '\t' << baseline.cp << '\t' << r.cp << '\t' << loss
                << '\t' << r.nodes << '\t' << r.depth << '\t' << r.bestmove << '\t' << r.pv << '\n';
        }
        return env->NewStringUTF(out.str().c_str());
    } catch (const std::exception& e) {
        const std::string msg = std::string("ERROR\t") + e.what();
        return env->NewStringUTF(msg.c_str());
    } catch (...) {
        return env->NewStringUTF("ERROR\tUnknown Stockfish exception");
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_brilliantmax_chess_NativeStockfish_nativeStop(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_engine) g_engine->stop();
    g_stop.store(true);
}

extern "C" JNIEXPORT void JNICALL
Java_com_brilliantmax_chess_NativeStockfish_nativeClose(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_engine) g_engine->stop();
    g_engine.reset();
}
