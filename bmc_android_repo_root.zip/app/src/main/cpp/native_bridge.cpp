#include <jni.h>
#include <atomic>
#include <string>
#include <vector>
#include <android/log.h>

static std::atomic<bool> stop_flag{false};

extern "C" JNIEXPORT jobjectArray JNICALL
Java_com_brilliantmax_chess_NativeSearch_analyzeNative(
    JNIEnv* env, jobject, jstring fen, jlong budget) {
    stop_flag.store(false);
    // v1.1 boundary:
    // 1) parse FEN
    // 2) batch-encode legal candidates
    // 3) run INT8 Brilliant Prior
    // 4) allocate exact node budget
    // 5) native search/verification
    // 6) return ranked AnalysisLine objects.
    //
    // No fake results are returned. Until the trained exported model and
    // verifier are inserted, the Java UI correctly reports "runtime not bundled".
    jclass cls = env->FindClass("com/brilliantmax/chess/AnalysisLine");
    return env->NewObjectArray(0, cls, nullptr);
}

extern "C" JNIEXPORT void JNICALL
Java_com_brilliantmax_chess_NativeSearch_stopNative(JNIEnv*, jobject) {
    stop_flag.store(true);
}
