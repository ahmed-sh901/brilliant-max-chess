import java.io.File
import java.net.URL
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val stockfishNetName = "nn-1a298aa575a0.nnue"
val stockfishNetUrl = "https://tests.stockfishchess.org/api/nn/$stockfishNetName"
val assetsDir = layout.projectDirectory.dir("src/main/assets").asFile
val stockfishNetFile = File(assetsDir, stockfishNetName)

fun sha256(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().use { input ->
        val buffer = ByteArray(1024 * 1024)
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            digest.update(buffer, 0, n)
        }
    }
    return digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
}

tasks.register("prepareStockfishNetwork") {
    outputs.file(stockfishNetFile)
    doLast {
        assetsDir.mkdirs()
        if (!stockfishNetFile.exists() || stockfishNetFile.length() < 1024L) {
            logger.lifecycle("Downloading Stockfish NNUE: $stockfishNetName")
            URL(stockfishNetUrl).openStream().use { input ->
                stockfishNetFile.outputStream().use { output -> input.copyTo(output) }
            }
        }
        val actual = sha256(stockfishNetFile)
        val expectedPrefix = stockfishNetName.removePrefix("nn-").removeSuffix(".nnue")
        check(actual.startsWith(expectedPrefix)) {
            "NNUE checksum prefix mismatch: expected $expectedPrefix, got ${actual.take(12)}"
        }
        File(assetsDir, "$stockfishNetName.sha256").writeText("$actual  $stockfishNetName\n")
        logger.lifecycle("Validated $stockfishNetName SHA-256=$actual")
    }
}

tasks.named("preBuild") { dependsOn("prepareStockfishNetwork") }
tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }.configureEach { dependsOn("prepareStockfishNetwork") }

android {
    namespace = "com.brilliantmax.chess"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.brilliantmax.chess"
        minSdk = 26
        targetSdk = 36
        versionCode = 130
        versionName = "1.3.0"
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild {
            cmake { cppFlags += listOf("-std=c++20") }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
        debug { isMinifyEnabled = false }
    }
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.2")
    implementation("org.pytorch:pytorch_android_lite:1.13.1")
    testImplementation("junit:junit:4.13.2")
}
