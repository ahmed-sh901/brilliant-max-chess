import MessageDigest
import MessageDigest
import java.util.zip.ZipFile
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.brilliantmax.chess"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.brilliantmax.chess"
        minSdk = 26
        targetSdk = 36
        versionCode = 132
        versionName = "1.3.2"
        ndk { abiFilters += listOf("arm64-v8a") }
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlin {
        compilerOptions {
            jvmTarget.set(JvmTarget.JVM_17)
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
        debug { isMinifyEnabled = false }
    }
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.2")

    // v1.2 runtime bridge for the already-exported TorchScript Lite model.
    // PyTorch Mobile is legacy; this is an intentional bridge milestone so the
    // existing .ptl can run on-device before the ExecuTorch .pte migration.
    implementation("org.pytorch:pytorch_android_lite:1.13.1")
    androidTestImplementation("androidx.test.ext:junit:1.3.0")
    androidTestImplementation("androidx.test:core:1.7.0")
    androidTestImplementation("androidx.test:runner:1.7.0")
    testImplementation("junit:junit:4.13.2")
}


val verifyBmcModelAsset by tasks.registering {
    val asset = project.file("src/main/assets/mobile_prior_v52_7head_mix2250.ptl")
    val expectedFile = project.file("src/main/assets/mobile_prior_v52_7head_mix2250.ptl.sha256")
    doLast {
        if (!asset.exists() || !expectedFile.exists()) throw GradleException("BMC Prior asset or checksum missing")
        val expected = expectedFile.readText().trim().split(Regex("\\s+"))[0]
        val actual = MessageDigest.getInstance("SHA-256").digest(asset.readBytes()).joinToString("") { b -> "%02x".format(b) }
        if (expected != actual) throw GradleException("BMC Prior asset SHA-256 mismatch: expected $expected actual $actual")
        ZipFile(asset).use { z ->
            if (z.getEntry("mobile_prior_v52_7head_mix2250_lite/bytecode.pkl") == null && z.entries().asSequence().none { it.name.endsWith("/bytecode.pkl") }) {
                throw GradleException("BMC Prior asset is not a TorchScript Lite model: bytecode.pkl missing")
            }
        }
    }
}

// CI builds the arm64 Stockfish 19 verifier from the pinned upstream tag before the APK.
// This keeps the repo reproducible without checking a 10s/100s MB third-party binary into Git.
val prepareStockfish by tasks.registering {
    val root = project.projectDir
    val thirdParty = root.resolve("../third_party")
    val source = thirdParty.resolve("stockfish")
    val jni = root.resolve("src/main/jniLibs/arm64-v8a")
    val assets = root.resolve("src/main/assets")
    outputs.file(jni.resolve("libstockfish.so"))
    outputs.file(assets.resolve("stockfish_nnue.nnue"))
    doLast {
        if (!source.resolve("src/Makefile").exists()) {
            thirdParty.mkdirs()
            exec { commandLine("git","clone","--depth","1","--branch","sf_19","https://github.com/official-stockfish/Stockfish.git",source.absolutePath) }
        }
        val ndkHome = System.getenv("ANDROID_NDK_HOME") ?: System.getenv("ANDROID_NDK_ROOT")
            ?: throw GradleException("ANDROID_NDK_HOME/ANDROID_NDK_ROOT is required to build Stockfish for Android")
        val llvmBin = File(ndkHome, "toolchains/llvm/prebuilt/linux-x86_64/bin")
        exec {
            environment("PATH", llvmBin.absolutePath + ":" + (System.getenv("PATH") ?: ""))
            workingDir(source.resolve("src"))
            commandLine("make","-j2","net")
        }
        exec {
            environment("PATH", llvmBin.absolutePath + ":" + (System.getenv("PATH") ?: ""))
            workingDir(source.resolve("src"))
            commandLine("make","-j2","build","COMP=ndk","ARCH=armv8","EXTRALDFLAGS=-Wl,-z,max-page-size=16384")
        }
        val binary = source.resolve("src/stockfish")
        if (!binary.exists()) throw GradleException("Stockfish build did not produce src/stockfish")
        jni.mkdirs(); binary.copyTo(jni.resolve("libstockfish.so"), overwrite=true)
        // Stockfish 19's compatible default network. The build target may have fetched it;
        // otherwise obtain the preserved network directly from the official network store.
        val net = source.resolve("src/nn-1a298aa575a0.nnue")
        if (!net.exists()) {
            exec { commandLine("curl","-L","--fail","--retry","3","-o",net.absolutePath,"https://tests.stockfishchess.org/api/nn/nn-1a298aa575a0.nnue") }
        }
        net.copyTo(assets.resolve("stockfish_nnue.nnue"), overwrite=true)
        assets.resolve("stockfish_nnue.nnue.sha256").writeText(net.inputStream().use { MessageDigest.getInstance("SHA-256").digest(it.readBytes()).joinToString("") { b -> "%02x".format(b) } } + "  stockfish_nnue.nnue\n")
        File(root,"STOCKFISH_BUILD_MANIFEST.txt").writeText("Stockfish 19 / sf_19 / edb0d9d\nAndroid arm64-v8a / COMP=ndk / ARCH=armv8\nDefault NNUE: nn-1a298aa575a0.nnue\nSource: https://github.com/official-stockfish/Stockfish\nLicense: GPL-3.0\n")
    }
}
tasks.named("preBuild") { dependsOn(verifyBmcModelAsset); dependsOn(prepareStockfish) }
