plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="com.brilliantmax.chess"
    compileSdk=36
    defaultConfig {
        applicationId="com.brilliantmax.chess"
        minSdk=26
        targetSdk=36
    compileOptions {
        sourceCompatibility=JavaVersion.VERSION_17
        targetCompatibility=JavaVersion.VERSION_17
    }
        versionCode=110
        versionName="1.1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    buildTypes {
        release { isMinifyEnabled=false }
        debug { isMinifyEnabled=false }
    }
    packaging { jniLibs { useLegacyPackaging=true } }
}
dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.2")
    // Runtime intentionally kept replaceable until the trained model export is frozen.
    // The first production target is an INT8 ONNX/LiteRT-compatible model.
}
