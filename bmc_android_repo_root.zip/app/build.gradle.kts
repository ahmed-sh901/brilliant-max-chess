plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.brilliantmax.chess"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.brilliantmax.chess"
        minSdk = 26
        targetSdk = 36
        versionCode = 120
        versionName = "1.2.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildTypes {
        release { isMinifyEnabled = false }
        debug { isMinifyEnabled = false }
    }
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.2")

    // v1.2 runtime bridge for the already-exported TorchScript Lite model.
    // PyTorch Mobile is legacy; this is an intentional bridge milestone so the
    // existing .ptl can run on-device before the ExecuTorch .pte migration.
    implementation("org.pytorch:pytorch_android_lite:1.13.1")
}
