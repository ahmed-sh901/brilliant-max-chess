# Brilliant-Max Chess v2.0 — Integrated Search Pipeline

This release stops treating the Android app as a Prior-only demo. It implements the first coherent BMC runtime pipeline:

1. Parse arbitrary FEN / maintain board state.
2. Ask Stockfish 19 for the legal root move set.
3. Encode the exact v1.52 Move-Aware 7-head Prior contract.
4. Rank all legal moves with the Prior.
5. Select the top creative candidates.
6. Verify each selected move with the same Stockfish node budget.
7. Audit sacrifice offer / accepted capture using the returned PV.
8. Measure response-space reduction by legal-response count.
9. Return only soundness-gated creative discoveries to the UI.

## Build architecture

GitHub Actions builds the arm64 Stockfish 19 binary from the pinned `sf_19` branch, embeds it as an Android asset, verifies the Prior Lite archive, builds the APK, runs unit tests, and checks that both runtime assets are inside the APK.

The Gradle project itself no longer clones repositories or downloads NNUE files during configuration. Network/build provisioning belongs in CI, making local Gradle configuration deterministic.

## Important limitations

- The Prior is a search guide, not a soundness authority.
- Stockfish 19 is the verifier, not the BMC creative objective.
- Sacrifice acceptance is a structural audit of the returned PV, not a claim that every sacrifice is brilliant.
- Device runtime execution of an Android Stockfish executable has not yet been validated on the target phone. This is deliberately a single final device gate after CI passes.
- The legacy `.ptl` runtime remains a compatibility bridge. ExecuTorch `.pte` migration is a later optimization/production phase; current ExecuTorch Android documentation recommends the AAR/Maven integration and XNNPACK as the compatibility-first backend.
