import com.brilliantmax.chess.*
fun perft(p:ChessPosition,d:Int):Long=if(d==0)1 else p.legalMoves().sumOf{perft(p.apply(it),d-1)}
fun main(){val p=ChessPosition.fromFen("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1");println(perft(p,1));println(perft(p,2));println(perft(p,3))}
