import com.brilliantmax.chess.*
fun perft(p:ChessPosition,d:Int):Long=if(d==0)1 else p.legalMoves().sumOf{perft(p.apply(it),d-1)}
fun main(){val p=ChessPosition.fromFen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1");println(perft(p,1));println(perft(p,2));println(perft(p,3))}
