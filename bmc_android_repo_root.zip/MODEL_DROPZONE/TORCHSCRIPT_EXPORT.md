# v1.52 TorchScript mobile export

File: `mobile_prior_v52_7head_mix2250.ptl`

Inputs:
- pieces `[B,64]` int64
- side `[B,1]` int64
- castling `[B,1]` int64
- ep `[B,1]` int64
- candidates `[B,C,3]` int64

Output: `[B,C,7]` float32 logits.

The export was numerically compared against the PyTorch module with maximum absolute error `7.15e-07` on the export probe.

The export is a model artifact, not an APK. Android inference still requires a runtime integration layer and device validation.
