# Brilliant-Max model handoff

Supported research checkpoint:
- `prior_v52_7head_mix2250.pt`
- model: Move-Aware 7-head Prior
- source checkpoint: `runs/prior_v52_7head_mix2250.pt`
- export schema: v1 state-dict package
- output heads: 7

This is a PyTorch state-dict export. It is **not an Android inference runtime** by itself.
A compatible mobile inference runtime must be integrated before this file can be used on-device.
