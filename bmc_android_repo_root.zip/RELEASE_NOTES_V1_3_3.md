# BMC Android v1.3.3

- Fixes Gradle Kotlin DSL `MessageDigest` references that previously compiled as `java.security` unresolved references.
- Keeps the explicit `MessageDigest` import and modern Kotlin compilerOptions JVM target.
- Fixes Prior promotion encoding at the Android boundary: internal ChessMove promotion values (Q/R/B/N = 5/4/3/2) are mapped to the frozen model contract (1/2/3/4).
- Bumps app version to 1.3.3 / versionCode 133.
- CI preflight now rejects the broken fully-qualified `java.security.MessageDigest.getInstance` form.
- No APK is claimed here; GitHub Actions remains the authoritative Android build environment.


