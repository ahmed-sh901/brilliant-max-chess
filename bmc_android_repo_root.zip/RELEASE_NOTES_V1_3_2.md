# Brilliant-Max Chess v1.3.2

CI-clean rebuild of the v1.3.1 mobile runtime milestone.

- Uses the real TorchScript Lite `.ptl` archive containing `bytecode.pkl`.
- Uses explicit `java.security.MessageDigest` import in Gradle Kotlin DSL.
- Keeps the v1.52 seven-head Prior unchanged.
- Keeps the Stockfish 19 verifier integration and Android instrumentation tests.
- VersionCode 132 / versionName 1.3.2.

This release is for CI/runtime validation only; it is not a claim of final mobile strength.
