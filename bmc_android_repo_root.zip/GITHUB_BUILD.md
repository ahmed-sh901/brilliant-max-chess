# BMC Android — GitHub build guide

This project is prepared to build on a GitHub-hosted Ubuntu runner. You do **not** need a PC, Android Studio, Android SDK, NDK, or Gradle installed locally.

## What you need

1. A GitHub account.
2. A repository you own (public is simplest).
3. Upload the contents of this folder to the repository root.
4. Open **Actions → BMC Android CI → Run workflow**.
5. After the run succeeds, open the run's **Artifacts** section and download `bmc-android-debug`.
6. Extract the APK on your Android phone and install it.

The workflow installs Android SDK/API 36, NDK 27.2.12479018, CMake 3.22.1, JDK 17, and Gradle 8.13 on the runner. It then verifies the bundled TorchScript model checksum, builds the debug APK, runs the available unit-test task, and uploads the APK as an artifact.

## Important status

A successful GitHub build proves that the **Android project compiles**. It does **not** yet prove that BMC's TorchScript model is actually used for inference in the native runtime.

Current v1.4 scope:
- GitHub CI build: prepared
- Android SDK/NDK provisioning: prepared
- Model checksum verification: prepared
- Debug APK artifact: prepared
- Native TorchScript inference runtime: still incomplete
- Full BMC engine/search integration: still incomplete

Do not treat a successful APK build as a completed BMC Android engine.
