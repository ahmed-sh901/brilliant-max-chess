# Brilliant-Max Chess v1.3 — real engine layer

## What changed

v1.3 moves the Android app from a model smoke test to a real BMC analysis pipeline.

### Implemented
- Full orthodox board state representation.
- FEN parsing and serialization.
- Legal move generation with king safety.
- Castling, en-passant and promotion handling.
- Arbitrary-position v1.52 Prior inference instead of a fixed opening candidate list.
- Prior ranking over all legal root moves.
- Stockfish 19 Android arm64 verifier built during CI from official `sf_19`.
- Per-candidate node-limited verification.
- Soundness gate: finite score >= -80 cp or positive mate.
- Sacrifice-offer detection based on an immediate legal opponent capture of the moved piece.
- Structural legal-response reduction measurement.
- Conservative accepted-capture hook from the verified PV.
- Ranked discovery output with Prior, verifier, response-space and sacrifice fields.
- Unit/perft coverage for start position, FEN round trip, castling and en-passant.

## What is deliberately not claimed

- This is not a playing-strength/Elo claim.
- The Prior's output is not treated as proof of soundness.
- A sacrifice offer is not called brilliant merely because it is spectacular.
- Legal-response reduction is not yet the final engine-viability response-space metric.
- Accepted sacrifice and chain length are research hooks pending deeper multi-ply verification.

## Stockfish build

CI downloads the official Stockfish `sf_19` source and builds an Android arm64-v8a binary with the Android NDK. The compatible default network is downloaded from the official Stockfish network store. See `docs/STOCKFISH_GPL.md`.
