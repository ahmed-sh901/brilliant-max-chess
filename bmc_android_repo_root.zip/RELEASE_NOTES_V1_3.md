# Brilliant-Max Chess v1.3

## First real search integration

v1.3 moves beyond the v1.2 model smoke test.

### Added
- full legal chess position representation and FEN support
- legal move generation with castling, en-passant, promotion and king-safety filtering
- canonical perft tests
- frozen v1.52 Prior inference over arbitrary legal positions
- native Stockfish Engine API integration for arm64 Android
- single-threaded node-budgeted candidate verification
- response-space reduction audit
- sacrifice-offer and accepted-sacrifice audit
- conservative sound/creative classification
- FEN load UI and interactive board moves
- real analysis result display

### Runtime dependencies
- Android arm64-v8a
- PyTorch Lite 1.13.1 for the frozen `.ptl` Prior bridge
- bundled Stockfish source
- validated Stockfish NNUE network downloaded during the build

### Important
This is an engineering milestone. It is not a playing-strength result and has not yet been benchmarked on-device against the desktop BMC verifier.
